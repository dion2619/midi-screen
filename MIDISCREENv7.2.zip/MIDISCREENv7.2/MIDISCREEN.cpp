#include "Arduino.h"
#include "MIDISCREEN.h"

MIDISCREEN :: MIDISCREEN()
{

 clk1   =    36;
 latch1 =    35;
 data1  =    37;
 Clear1 =    31;
 OE1    =    30;
 
 
 clk2   =    23 ;
 latch2 =    24 ;
 data2  =    22 ;
 Clear2 =    28 ;
 OE2    =    29 ;
 
 
 clk3   =    A9 ;
 latch3 =    A10 ;
 data3  =    A8 ;
 Clear3 =    A14 ;
 OE3    =    A15 ;
 
 
 clk4   =    A1 ;
 latch4 =    A2 ;
 data4  =    A0;
 Clear4 =    A6 ;
 OE4    =    A7 ;
 
 
 
 row0[90];
 row1[90];
 row2[90];
 row3[90];
 lowestlednote = 23;
 



pinMode(clk1,OUTPUT);
pinMode(latch1,OUTPUT);
pinMode(data1,OUTPUT);
pinMode(Clear1,OUTPUT);
pinMode(OE1,OUTPUT);
pinMode(clk2,OUTPUT);
pinMode(latch2,OUTPUT);
pinMode(data2,OUTPUT);
pinMode(Clear2,OUTPUT);
pinMode(OE2,OUTPUT);
pinMode(clk3,OUTPUT);
pinMode(latch3,OUTPUT);
pinMode(data3,OUTPUT);
pinMode(Clear3,OUTPUT);
pinMode(OE3,OUTPUT);
pinMode(clk4,OUTPUT);
pinMode(latch4,OUTPUT);
pinMode(data4,OUTPUT);
pinMode(Clear4,OUTPUT);
pinMode(OE4,OUTPUT);

digitalWrite(Clear1,1);
digitalWrite(Clear2,1);
digitalWrite(Clear3,1);
digitalWrite(Clear4,1);

pinMode(13,OUTPUT);
Serial1.begin(9600);
Serial2.begin(31250);


	
	
	
}
void MIDISCREEN :: clearScreen()
{



digitalWrite(Clear1,0);
digitalWrite(Clear2,0);
digitalWrite(Clear3,0);
digitalWrite(Clear4,0);

digitalWrite(Clear1,1);
digitalWrite(Clear2,1);
digitalWrite(Clear3,1);
digitalWrite(Clear4,1);


digitalWrite(latch1,1);
digitalWrite(latch1,0);

digitalWrite(latch2,1);
digitalWrite(latch2,0);

digitalWrite(latch3,1);
digitalWrite(latch3,0);

digitalWrite(latch4,1);
digitalWrite(latch4,0);
}

void MIDISCREEN :: loadrow(int ch)
{


 switch(ch)
 {
  case 0:
for(int i = 0; i < 90; i++)
{
digitalWrite(data1,row0[i]);
digitalWrite(clk1,1);
digitalWrite(clk1,0);

}
digitalWrite(latch1,1);
digitalWrite(latch1,0);
  break;

   case 1:
for(int i = 0; i < 90; i++)
{
digitalWrite(data2,row1[i]);
digitalWrite(clk2,1);
digitalWrite(clk2,0);

}
digitalWrite(latch2,1);
digitalWrite(latch2,0);
  break;

   case 2:
for(int i = 0; i < 90; i++)
{
digitalWrite(data3,row2[i]);
digitalWrite(clk3,1);
digitalWrite(clk3,0);

}
digitalWrite(latch3,1);
digitalWrite(latch3,0);
  break;

   case 3:
for(int i = 0; i < 90; i++)
{
digitalWrite(data4,row3[i]);
digitalWrite(clk4,1);
digitalWrite(clk4,0);

}
digitalWrite(latch4,1);
digitalWrite(latch4,0);
  break;
 }
}	

void MIDISCREEN :: midiNoteOn(int ch, int pitch, int velocity)
{
	
	
	
	

  if(ch <= 3 )
  {
  setledon(ch,pitch);
  if(velocity == 0)
  {
    setledoff(ch,pitch); 
  }
  }

  if(ch >= 4)
  {
  setledon(3,pitch);
 
  if(velocity == 0)
  {
    setledoff(3,pitch); 

	
  }
  }

  
  
  


  
  
  
}

void MIDISCREEN :: midiNoteOff(int ch, int pitch)
{
 
  if(ch <= 3)
  {
  setledoff(ch,pitch);
  }

  if(ch >= 4)
  {
    setledoff(3,pitch);
  }
}





void MIDISCREEN :: setledon(int ch, int note)
{
int ledadd = note - lowestlednote;//lowest note on led disp
switch(ch)
{
  case 0: row0[ledadd] = 1;  loadrow(0); break;
  case 1: row1[ledadd] = 1;  loadrow(1); break;
  case 2: row2[ledadd] = 1;  loadrow(2); break;
  case 3: row3[ledadd] = 1;  loadrow(3); break;
} 
}

void MIDISCREEN :: setledoff(int ch, int note)
{
int ledadd = note - lowestlednote;
switch(ch)
{
case 0: row0[ledadd] = 0; loadrow(0); break;
case 1: row1[ledadd] = 0; loadrow(1); break;
case 2: row2[ledadd] = 0; loadrow(2); break;
case 3: row3[ledadd] = 0; loadrow(3); break;
}
}

void MIDISCREEN :: readmidiport()
{
	
  static byte controll = 0;
  static byte pitch    = 0;
  static byte velocity = 0;
  
      static const long interval1 = 50; 
	static const long interval2 = 50; 
	static const long interval3 = 50; 
	static const long interval4 = 50; 
	static const long interval5 = 50; 
	static const long interval6 = 50; 
	static const long interval7 = 50; 
	static const long interval8 = 50; 
	static const long interval9 = 150;
	static const long interval10 = 50;
	static const long interval11 = 50;
	static const long interval12 = 50;
	static const long interval13 = 50;
    unsigned long currentMillis = millis();
	
	
	
		
 if (currentMillis - starttime1 >= interval1 && timeren1 == 1) //35 kick drum timer
   {
    starttime1 = currentMillis;
    setledoff(3,35);
	timeren1 = 0;
	}
	
 if (currentMillis - starttime2 >= interval2 && timeren2 == 1) //36 kick drum timer
   {
    starttime2 = currentMillis;
    setledoff(3,36);
	timeren2 = 0;
	}
	
 if (currentMillis - starttime3 >= interval3 && timeren3 == 1) //38 snare drum timer
   {
    starttime3 = currentMillis;
    setledoff(3,38);
	timeren3 = 0;
	
	}
	
 if (currentMillis - starttime4 >= interval4 && timeren4 == 1) //40 snare drum timer
   {
    starttime4 = currentMillis;
    setledoff(3,40);
	timeren4 = 0;
	
	}
	
	
 if (currentMillis - starttime5 >= interval5 && timeren5 == 1) //41 toms 1 timer
   {	
	starttime5 = currentMillis;
    setledoff(3,41);
	timeren5 = 0;
   }
   
   
 if (currentMillis - starttime6 >= interval6 && timeren6 == 1) //42 hi hat closed drum timer
   {
    starttime6 = currentMillis;
    setledoff(3,42);
	timeren6 = 0;
	
	}
	
		
 if (currentMillis - starttime7 >= interval7 && timeren7 == 1) //43 toms 2 timer
   {
    starttime7 = currentMillis;
   setledoff(3,43);
	timeren7 = 0;
	
	}
	
 if (currentMillis - starttime8 >= interval8 && timeren8 == 1) //44 hi hat pedal drum timer
   {	
         starttime8 = currentMillis;
    setledoff(3,44);
	timeren8 = 0;
	
	}
 if (currentMillis - starttime9 >= interval9 && timeren9 == 1) //45 toms 3 timer
   {
    starttime9 = currentMillis;
    setledoff(3,45);
	timeren9 = 0;
	
	}
	
 if (currentMillis - starttime10 >= interval10 && timeren10 == 1) //46 hi hat open drum timer
  {	
      starttime10 = currentMillis;
   setledoff(3,46);
	timeren10 = 0;
	
	}
	
 if (currentMillis - starttime11 >= interval11 && timeren11 == 1) //47 toms 4 timer
   {
    starttime11 = currentMillis;
   setledoff(3,47);
	timeren11 = 0;
	
	}
	
	
 if (currentMillis - starttime12 >= interval12 && timeren12 == 1) //48 toms 5 timer
   {
    starttime12 = currentMillis;
   setledoff(3,48);
	timeren12 = 0;
	
	}
	
	
 if (currentMillis - starttime13 >= interval13 && timeren13 == 1) //50 toms 6 timer
   {
	
	  starttime13 = currentMillis;
   setledoff(3,50);
	timeren13 = 0;
	
	}
	
	
	
	
  
  if  (Serial1.available()>=3)//from master cpu
  {
  digitalWrite(13,1);
  controll =  Serial1.read();
  
  if(controll == 120 || controll == 123){clearScreen();}


	
  if(controll > 127 && controll < 160)//note on off messages
  {
  pitch    =  Serial1.read();
  velocity =  Serial1.read();
  switch(controll)
  {
    case 128:midiNoteOff(0,pitch);break;
    case 129:midiNoteOff(1,pitch);break;
    case 130:midiNoteOff(2,pitch);break;
    case 131:midiNoteOff(3,pitch);break;
    case 132:midiNoteOff(4,pitch);break;
    case 133:midiNoteOff(5,pitch);break;
    case 134:midiNoteOff(6,pitch);break;
    case 135:midiNoteOff(7,pitch);break;
    case 136:midiNoteOff(8,pitch);break;
    case 137:ch10handleoff(pitch);break;
    case 138:midiNoteOff(10,pitch);break;
    case 139:midiNoteOff(11,pitch);break;
    case 140:midiNoteOff(12,pitch);break;
    case 141:midiNoteOff(13,pitch);break;
    case 142:midiNoteOff(14,pitch);break;
    case 143:midiNoteOff(15,pitch);break;
    case 144:midiNoteOn(0,pitch,velocity);break;
    case 145:midiNoteOn(1,pitch,velocity);;break;
    case 146:midiNoteOn(2,pitch,velocity);break;
    case 147:midiNoteOn(3,pitch,velocity);break;
    case 148:midiNoteOn(4,pitch,velocity);break;
    case 149:midiNoteOn(5,pitch,velocity);break;
    case 150:midiNoteOn(6,pitch,velocity);break;
    case 151:midiNoteOn(7,pitch,velocity);break;
    case 152:midiNoteOn(8,pitch,velocity);break;
    case 153:if(velocity > 0){ch10handleon(pitch);}break;
    case 154:midiNoteOn(10,pitch,velocity);break;
    case 155:midiNoteOn(11,pitch,velocity);break;
    case 156:midiNoteOn(12,pitch,velocity);break;
    case 157:midiNoteOn(13,pitch,velocity);break;
    case 158:midiNoteOn(14,pitch,velocity);break;
    case 159:midiNoteOn(15,pitch,velocity);break;
	}//end note off

	}
}//end serial2 in


   digitalWrite(13,0);
  }




void MIDISCREEN :: setbit(byte ch, byte address, byte databit)	
{
	
	switch(ch)
	{
	case 0: row0[address] = databit; break;
	case 1: row1[address] = databit; break;
	case 2: row2[address] = databit; break;
	case 3: row3[address] = databit; break;
    }		
}




void MIDISCREEN :: ch10handleon(byte pitch)
{
	
switch (pitch)
{
  case 35: starttime1 = millis(); timeren1 = 1;   setledon(3,pitch); break;
  case 36: starttime2 = millis(); timeren2 = 1;   setledon(3,pitch); break;//start timer on note
  case 38: starttime3 = millis(); timeren3 = 1;   setledon(3,pitch); break;
  case 40: starttime4 = millis(); timeren4 = 1;   setledon(3,pitch); break;
  case 41: starttime5 = millis(); timeren5 = 1;   setledon(3,pitch); break;
  case 42: starttime6 = millis(); timeren6 = 1;   setledon(3,pitch); break;
  case 43: starttime7 = millis(); timeren7 = 1;   setledon(3,pitch); break;
  case 44: starttime8 = millis(); timeren8 = 1;   setledon(3,pitch); break;
  case 45: starttime9 = millis(); timeren9 = 1;   setledon(3,pitch); break;
  case 46: starttime10 = millis(); timeren10 = 1; setledon(3,pitch); break;
  case 47: starttime11 = millis(); timeren11 = 1; setledon(3,pitch); break;
  case 48: starttime12 = millis(); timeren12 = 1; setledon(3,pitch); break;
  case 50: starttime13 = millis(); timeren13 = 1; setledon(3,pitch); break;
	
	
	
}
	
	
	
	
	
	
	
	
}



void MIDISCREEN :: ch10handleoff(byte pitch)
{
	

	
	
}








