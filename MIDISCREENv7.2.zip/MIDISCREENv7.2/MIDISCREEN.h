#include "Arduino.h"

class MIDISCREEN

{
public:
MIDISCREEN();
void clearScreen();
void loadrow(int ch);
void setdata(int ch, int data);
void midiNoteOn(int ch, int pitch, int velocity);
void midiNoteOff(int ch, int pitch);
void setledon(int ch, int note);
void setledoff(int ch, int note);
void readmidiport();
void ch10handleon(byte pitch);
void ch10handleoff(byte pitch);
void setbit(byte addresss, byte databit, byte ch);




private:
	bool timeren1;
	bool timeren2;
	bool timeren3;
	bool timeren4;
	bool timeren5;
	bool timeren6;
	bool timeren7;
	bool timeren8;
	bool timeren9;
	bool timeren10;
	bool timeren11;
	bool timeren12;
	bool timeren13;
	
	
	
	unsigned long starttime1; 
	unsigned long starttime2; 
	unsigned long starttime3; 
	unsigned long starttime4; 
	unsigned long starttime5; 
	unsigned long starttime6; 
	unsigned long starttime7; 
	unsigned long starttime8; 
	unsigned long starttime9; 
	unsigned long starttime10; 
	unsigned long starttime11; 
	unsigned long starttime12; 
	unsigned long starttime13; 	
int clk1      ; 
int latch1    ; 
int data1     ; 
int Clear1    ; 
int OE1       ; 
int clk2      ; 
int latch2    ; 
int data2     ; 
int Clear2    ; 
int OE2       ; 
int clk3      ; 
int latch3    ; 
int data3     ; 
int Clear3    ; 
int OE3       ; 
int clk4      ; 
int latch4    ; 
int data4     ; 
int Clear4    ; 
int OE4       ; 
bool row0[90];
bool row1[90];
bool row2[90];
bool row3[90];
int lowestlednote;

	
};



