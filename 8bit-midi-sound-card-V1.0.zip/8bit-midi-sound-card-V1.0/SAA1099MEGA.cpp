
#include "Arduino.h"
#include "SAA1099MEGA.h"
#include "EEPROM.h"



#include <Adafruit_GFX.h>  // Include core graphics library for the display
#include <Adafruit_SSD1306.h>  // Include Adafruit_SSD1306 library to drive the display

	Adafruit_SSD1306 display;  // Create di




 SAA1099MEGA ::  SAA1099MEGA()
{
# define A0PIN 3
# define WRPIN 4
# define CS1PIN 5
# define CS2PIN 6
# define CS3PIN 7


tunepos = 1;

midiEn = 0;
chOn1 = 0;
chOn2 = 0;
chOn3 = 0;
chOn4 = 0;
chOn5 = 0;
chOn6 = 0;
chOn7 = 0;
chOn8 = 0;
chOn9 = 0;
chOn10 = 0;
chOn11 = 0;
chOn12 = 0;
chOn13 = 0;
chOn14 = 0;
chOn15 = 0;
chOn16 = 0;

byte chvol1 = 0;
byte chvol2 = 0;
byte chvol3 = 0;
byte chvol4 = 0;
byte chvol5 = 0;
byte chvol6 = 0;
byte chvol7 = 0;
byte chvol8 = 0;
byte chvol9 = 0;
byte chvol10 = 0;
byte chvol11 = 0;
byte chvol12 = 0;
byte chvol13 = 0;
byte chvol14 = 0;
byte chvol15 = 0;
byte chvol16 = 0;


chOnPitch1 = 0;
chOnPitch2 = 0;
chOnPitch3 = 0;
chOnPitch4 = 0;
chOnPitch5 = 0;
chOnPitch6 = 0;
chOnPitch7 = 0;
chOnPitch8 = 0;
chOnPitch9 = 0;
chOnPitch10 = 0;
chOnPitch11 = 0;
chOnPitch12 = 0;
chOnPitch13 = 0;
chOnPitch14 = 0;
chOnPitch15 = 0;
chOnPitch16 = 0;


timeren1 = 0;
starttime1 = 0; 

timeren2 = 0;
starttime2 = 0; 

timeren3 = 0;
starttime3 = 0; 

timeren4 = 0;
starttime4 = 0; 

timeren5 = 0;
starttime5 = 0; 


b  = EEPROM.read(0);
c  = EEPROM.read(1);
cs = EEPROM.read(2);
d  = EEPROM.read(3);
ds = EEPROM.read(4);
e  = EEPROM.read(5);
f  = EEPROM.read(6);
fs = EEPROM.read(7);
g  = EEPROM.read(8);
gs = EEPROM.read(9);
a  = EEPROM.read(10);
as = EEPROM.read(11);
DDRA  = 0xff;//lower 6 bits for led controll
DDRB  = 0x0f;//lower 4 bits output  SEQ MUX ADDRESS BUS
DDRF  = 0xf8;//upper 5 bits  SAA1099 CONTROLL LINES
DDRK  = 0xff;//8 bits setSerialOutput to output  DATA BUS REGISTOR
PORTF = 0xf8;//pull up controll lines
pinMode(13,OUTPUT);

}


void SAA1099MEGA ::  A0low(){PORTF &=~_BV(A0PIN);}//High to low
void SAA1099MEGA ::  A0high(){PORTF |= _BV(A0PIN);}//low to high
void SAA1099MEGA ::  CS1low(){PORTF &=~_BV(CS1PIN);}//High to low
void SAA1099MEGA ::  CS1high(){PORTF |= _BV(CS1PIN);}//low to high
void SAA1099MEGA ::  CS2low(){PORTF &=~_BV(CS2PIN);}//High to low
void SAA1099MEGA ::  CS2high(){PORTF |= _BV(CS2PIN);}//low to high
void SAA1099MEGA ::  CS3low(){PORTF &=~_BV(CS3PIN);}//High to low
void SAA1099MEGA ::  CS3high(){PORTF |= _BV(CS3PIN);}//low to high
void SAA1099MEGA ::  WRpulse(){PINF |=_BV(WRPIN);PINF |=_BV(WRPIN);}

void SAA1099MEGA :: powerUpRegistorSet()
{

defaultRegistorSet(1);
defaultRegistorSet(2);
defaultRegistorSet(3);
Serial2.begin(31250); //port 2 for optical isolator, port 1 for rx, tx lines
Serial1.begin(9600); //port 1 for LED DRIVER
display.begin(SSD1306_SWITCHCAPVCC, 0x3c);  // Initialize display with the I2C address of 0x3C
 display.setTextColor(WHITE);

 display.clearDisplay();  // Clear the display so we can refresh
//////
  display.setCursor(15, 0);  // (x,y)
  display.println(" BIT MIDI CARD");  // Text or value to print
  display.setCursor(28, 10);  // (x,y)
  display.println("26/08/2020");  // Text or value to print
 ////// 
  display.display();  // Print everything we set previously 


  delay(2000);

 

}



 
void SAA1099MEGA :: loadAddressByteToChip(byte address, byte chip)
{
switch(address)
{


    case 0:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 1:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 2:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 3:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 4:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 5:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 6:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 7:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 8:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 9:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 10:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 11:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 12:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 13:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 14:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 15:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 16:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 17:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 18:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 19:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 20:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 21:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 22:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 23:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 24:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



	case 25:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 26:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 27:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 28:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 29:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



    case 30:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;



	case 31:
    switch (chip)
   {case 1:CS1low();break;// 1 select chip to write to
    case 2:CS2low();break;// 2
    case 3:CS3low();break;}//3
    PORTK = address;//load address to bus reg
    WRpulse();
    switch (chip)
   {case 1:CS1high();break;// 1 deselect chip
    case 2:CS2high();break;// 2
    case 3:CS3high();break;}//3
    break;

}
}

void SAA1099MEGA :: loadDataByteToChip(byte data, byte chip)
{
	A0low();
    switch (chip){case 1: CS1low(); break; case 2: CS2low(); break; case 3: CS3low();break;}
    PORTK = data;
    WRpulse();
    switch (chip){case 1: CS1high(); break; case 2: CS2high();break; case 3:CS3high();break;}
    A0high();
}

void SAA1099MEGA :: loadRegistor(byte address, byte chip, byte data)
{

switch (address)
{
	case 0: loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 1: loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 2: loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 3: loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 4: loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 5: loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 6: loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 7: loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 8: loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 9: loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 10:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 11:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 12:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 13:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 14:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 15:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 16:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 17:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 18:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 19:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 20:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 21:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 22:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 23:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 24:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 25:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 26:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 27:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 28:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 29:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 30:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
	case 31:loadAddressByteToChip(address,chip); loadDataByteToChip(data,chip); break;
}
}

void SAA1099MEGA :: defaultRegistorSet(byte chip)
{



	loadRegistor(0x0, chip,     0x66);
	loadRegistor(0x1, chip,     0x66);
	loadRegistor(0x2, chip,     0x66);
	loadRegistor(0x3, chip,     0x66);
	loadRegistor(0x4, chip,     0x66);
	loadRegistor(0x5, chip,     0x66);
	loadRegistor(0x6, chip,     0x00);
	loadRegistor(0x7, chip,     0x00);
	loadRegistor(0x8, chip,     0x00);
	loadRegistor(0x9, chip,     0x00);
	loadRegistor(0x0a,chip,     0x00);
	loadRegistor(0x0b,chip,     0x00);
	loadRegistor(0x0c,chip,     0x00);
	loadRegistor(0x0d,chip,     0x00);
	loadRegistor(0x0e,chip,     0x00);
	loadRegistor(0x0f,chip,     0x00);
	loadRegistor(0x10,chip,     0x00);
	loadRegistor(0x11,chip,     0x00);
	loadRegistor(0x12,chip,     0x00);
	loadRegistor(0x13,chip,     0x00);
	loadRegistor(0x14,chip,     0x00);
	loadRegistor(0x15,chip,     0x00);
	loadRegistor(0x16,chip,     B00110011);//noise mode
	loadRegistor(0x17,chip,     0x00);
	loadRegistor(0x18,chip,     0x00);
	loadRegistor(0x19,chip,     0x00);
	loadRegistor(0x1a,chip,     0x00);
	loadRegistor(0x1b,chip,     0x00);
	loadRegistor(0x1c,chip,     0x01);
	loadRegistor(0x1d,chip,     0x00);
	loadRegistor(0x1e,chip,     0x00);
	loadRegistor(0x1f,chip,     0x00);
	
	loadRegistor(0x0, 3,     0xff);//ch 13
	loadRegistor(0x3, 3,     0xff);//ch 16
	
}

void SAA1099MEGA :: channelEnableSet(byte ch, bool en)
{
	static byte enableByte = 0x00;
	static bool channelEnableChip1[] = {0,0,0,0,0,0,0,0};
	static bool channelEnableChip2[] = {0,0,0,0,0,0,0,0};
	static bool channelEnableChip3[] = {0,0,0,0,0,0,0,0};
    static bool noiseEnableChip3[] = {0,0,0,0,0,0,0,0};
	
switch(ch)
{
	case 1:
	channelEnableChip1[0] = en;
	digitalWrite(22,en);//////////////////////////////////////////////////////////////////////////////////////////////////////
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,channelEnableChip1[i]);}
	loadAddressByteToChip(0x14,1);
	loadDataByteToChip(enableByte,1);	
	break;


    case 2:
	channelEnableChip1[1] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,channelEnableChip1[i]);}
	loadAddressByteToChip(0x14,1);
	loadDataByteToChip(enableByte,1);
	break;


    case 3:
	channelEnableChip1[2] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,channelEnableChip1[i]);}
	loadAddressByteToChip(0x14,1);
	loadDataByteToChip(enableByte,1);
	break;


    case 4:
	channelEnableChip1[3] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,channelEnableChip1[i]);}
	loadAddressByteToChip(0x14,1);
	loadDataByteToChip(enableByte,1);
	break;


    case 5:
	channelEnableChip1[4] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,channelEnableChip1[i]);}
	loadAddressByteToChip(0x14,1);
	loadDataByteToChip(enableByte,1);
	break;


    case 6:
	channelEnableChip1[5] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,channelEnableChip1[i]);}
	loadAddressByteToChip(0x14,1);
	loadDataByteToChip(enableByte,1);
	break;


    case 7:
	channelEnableChip2[0] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,channelEnableChip2[i]);}
	loadAddressByteToChip(0x14,2);
	loadDataByteToChip(enableByte,2);
	break;


    case 8:
	channelEnableChip2[1] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,channelEnableChip2[i]);}
	loadAddressByteToChip(0x14,2);
	loadDataByteToChip(enableByte,2);
	break;


    case 9:
	channelEnableChip2[2] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,channelEnableChip2[i]);}
	loadAddressByteToChip(0x14,2);
	loadDataByteToChip(enableByte,2);
	break;


    case 10:
	channelEnableChip2[3] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,channelEnableChip2[i]);}
	loadAddressByteToChip(0x14,2);
	loadDataByteToChip(enableByte,2);
	break;


    case 11:
	channelEnableChip2[4] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,channelEnableChip2[i]);}
	loadAddressByteToChip(0x14,2);
	loadDataByteToChip(enableByte,2);
	break;


    case 12:
	channelEnableChip2[5] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,channelEnableChip2[i]);}
	loadAddressByteToChip(0x14,2);
	loadDataByteToChip(enableByte,2);
	break;


    case 13:
	channelEnableChip3[0] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,channelEnableChip3[i]);}
	loadAddressByteToChip(0x14,3);
	loadDataByteToChip(enableByte,3);
	break;


    case 14:
	channelEnableChip3[1] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,channelEnableChip3[i]);}
	loadAddressByteToChip(0x14,3);
	loadDataByteToChip(enableByte,3);
	break;


    case 15:
	channelEnableChip3[2] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,channelEnableChip3[i]);}
	loadAddressByteToChip(0x14,3);
	loadDataByteToChip(enableByte,3);
	break;


    case 16:
	channelEnableChip3[3] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,channelEnableChip3[i]);}
	loadAddressByteToChip(0x14,3);
	loadDataByteToChip(enableByte,3);
	break;


    case 17:
	channelEnableChip3[4] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,channelEnableChip3[i]);}
	loadAddressByteToChip(0x14,3);
	loadDataByteToChip(enableByte,3);
	break;


    case 18:
	channelEnableChip3[5] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,channelEnableChip3[i]);}
	loadAddressByteToChip(0x14,3);
	loadDataByteToChip(enableByte,3);
	break;
	
	//////////////////////////////////////noise gen 1
	    case 19:
	noiseEnableChip3[0] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,noiseEnableChip3[i]);}
	loadAddressByteToChip(0x15,3);
	loadDataByteToChip(enableByte,3);
	break;


    case 20:
	noiseEnableChip3[1] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,noiseEnableChip3[i]);}
	loadAddressByteToChip(0x15,3);
	loadDataByteToChip(enableByte,3);
	break;


    case 21:
	noiseEnableChip3[2] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,noiseEnableChip3[i]);}
	loadAddressByteToChip(0x15,3);
	loadDataByteToChip(enableByte,3);
	break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//gen 2
    case 22:
	noiseEnableChip3[3] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,noiseEnableChip3[i]);}
	loadAddressByteToChip(0x15,3);
	loadDataByteToChip(enableByte,3);
	break;


    case 23:
	noiseEnableChip3[4] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,noiseEnableChip3[i]);}
	loadAddressByteToChip(0x15,3);
	loadDataByteToChip(enableByte,3);
	break;


    case 24:
	noiseEnableChip3[5] = en;
	for (int i = 0; i < 8; i++){ enableByte = bitWrite(enableByte,i,noiseEnableChip3[i]);}
	loadAddressByteToChip(0x15,3);
	loadDataByteToChip(enableByte,3);
	break;

}

}

void SAA1099MEGA :: channelPitchSet(byte ch, byte pitch)
{
	switch (ch)
	{
	case 1: loadAddressByteToChip(0x08,1);loadDataByteToChip(pitch,1);break;
	case 2: loadAddressByteToChip(0x09,1);loadDataByteToChip(pitch,1);break;
	case 3: loadAddressByteToChip(0x0a,1);loadDataByteToChip(pitch,1);break;
	case 4: loadAddressByteToChip(0x0b,1);loadDataByteToChip(pitch,1);break;
	case 5: loadAddressByteToChip(0x0c,1);loadDataByteToChip(pitch,1);break;
	case 6: loadAddressByteToChip(0x0d,1);loadDataByteToChip(pitch,1);break;
	case 7: loadAddressByteToChip(0x08,2);loadDataByteToChip(pitch,2);break;
	case 8: loadAddressByteToChip(0x09,2);loadDataByteToChip(pitch,2);break;
	case 9: loadAddressByteToChip(0x0a,2);loadDataByteToChip(pitch,2);break;
	case 10:loadAddressByteToChip(0x0b,2);loadDataByteToChip(pitch,2);break;
	case 11:loadAddressByteToChip(0x0c,2);loadDataByteToChip(pitch,2);break;
	case 12:loadAddressByteToChip(0x0d,2);loadDataByteToChip(pitch,2);break;
	case 13:loadAddressByteToChip(0x08,3);loadDataByteToChip(pitch,3);break;
	case 14:loadAddressByteToChip(0x09,3);loadDataByteToChip(pitch,3);break;
	case 15:loadAddressByteToChip(0x0a,3);loadDataByteToChip(pitch,3);break;
	case 16:loadAddressByteToChip(0x0b,3);loadDataByteToChip(pitch,3);break;
	case 17:loadAddressByteToChip(0x0c,3);loadDataByteToChip(pitch,3);break;
	case 18:loadAddressByteToChip(0x0d,3);loadDataByteToChip(pitch,3);break;}
	}

void SAA1099MEGA :: loadOctaveByteToChip(byte ch, byte range)
{

	static byte octaveByte   = 0x00;
	static bool octaveChA[]  = {0,0,0,0,0,0,0,0};  //1 AND 2
	static bool octaveChB[]  = {0,0,0,0,0,0,0,0};  //3 AND 4
	static bool octaveChC[]  = {0,0,0,0,0,0,0,0};  //5 AND 6
	static bool octaveChD[]  = {0,0,0,0,0,0,0,0};  //7 AND 8
	static bool octaveChE[]  = {0,0,0,0,0,0,0,0};  //9 AND 10
	static bool octaveChF[]  = {0,0,0,0,0,0,0,0};  //11 AND 12
	static bool octaveChG[]  = {0,0,0,0,0,0,0,0};  //13 AND 14
	static bool octaveChH[]  = {0,0,0,0,0,0,0,0};  //15 AND 16
	static bool octaveChI[]  = {0,0,0,0,0,0,0,0};  //17 AND 18

	switch (ch)
	{
	case 1:
	switch(range)
	{
	case 0:  octaveChA[2] = 0;  octaveChA[1] = 0;  octaveChA[0] = 0; break;
	case 1:  octaveChA[2] = 0;  octaveChA[1] = 0;  octaveChA[0] = 1; break;
	case 2:  octaveChA[2] = 0;  octaveChA[1] = 1;  octaveChA[0] = 0; break;
	case 3:  octaveChA[2] = 0;  octaveChA[1] = 1;  octaveChA[0] = 1; break;
	case 4:  octaveChA[2] = 1;  octaveChA[1] = 0;  octaveChA[0] = 0; break;
	case 5:  octaveChA[2] = 1;  octaveChA[1] = 0;  octaveChA[0] = 1; break;
	case 6:  octaveChA[2] = 1;  octaveChA[1] = 1;  octaveChA[0] = 0; break;
	case 7:  octaveChA[2] = 1;  octaveChA[1] = 1;  octaveChA[0] = 1; break;
	}
	for (int i = 0; i < 8; i++){   octaveByte = bitWrite(octaveByte,i,octaveChA[i]);}
	loadDataByteToChip(octaveByte,1);
	break;


	case 2:
	switch(range)
	{
	case 0:  octaveChA[6] = 0;  octaveChA[5] = 0;  octaveChA[4] = 0; break;
	case 1:  octaveChA[6] = 0;  octaveChA[5] = 0;  octaveChA[4] = 1; break;
	case 2:  octaveChA[6] = 0;  octaveChA[5] = 1;  octaveChA[4] = 0; break;
	case 3:  octaveChA[6] = 0;  octaveChA[5] = 1;  octaveChA[4] = 1; break;
	case 4:  octaveChA[6] = 1;  octaveChA[5] = 0;  octaveChA[4] = 0; break;
	case 5:  octaveChA[6] = 1;  octaveChA[5] = 0;  octaveChA[4] = 1; break;
	case 6:  octaveChA[6] = 1;  octaveChA[5] = 1;  octaveChA[4] = 0; break;
	case 7:  octaveChA[6] = 1;  octaveChA[5] = 1;  octaveChA[4] = 1; break;
	}
	for (int i = 0; i < 8; i++){ octaveByte = bitWrite(octaveByte,i,octaveChA[i]);}
	loadDataByteToChip(octaveByte,1);
	break;


	case 3:
	switch(range)
	{
	case 0:  octaveChB[2] = 0;  octaveChB[1] = 0;  octaveChB[0] = 0; break;
	case 1:  octaveChB[2] = 0;  octaveChB[1] = 0;  octaveChB[0] = 1; break;
	case 2:  octaveChB[2] = 0;  octaveChB[1] = 1;  octaveChB[0] = 0; break;
	case 3:  octaveChB[2] = 0;  octaveChB[1] = 1;  octaveChB[0] = 1; break;
	case 4:  octaveChB[2] = 1;  octaveChB[1] = 0;  octaveChB[0] = 0; break;
	case 5:  octaveChB[2] = 1;  octaveChB[1] = 0;  octaveChB[0] = 1; break;
	case 6:  octaveChB[2] = 1;  octaveChB[1] = 1;  octaveChB[0] = 0; break;
	case 7:  octaveChB[2] = 1;  octaveChB[1] = 1;  octaveChB[0] = 1; break;
	}
	for (int i = 0; i < 8; i++){octaveByte = bitWrite(octaveByte,i,octaveChB[i]);}
	loadDataByteToChip(octaveByte,1);
	break;


	case 4:
	switch(range)
	{
	case 0:  octaveChB[6] = 0;  octaveChB[5] = 0;  octaveChB[4] = 0; break;
	case 1:  octaveChB[6] = 0;  octaveChB[5] = 0;  octaveChB[4] = 1; break;
	case 2:  octaveChB[6] = 0;  octaveChB[5] = 1;  octaveChB[4] = 0; break;
	case 3:  octaveChB[6] = 0;  octaveChB[5] = 1;  octaveChB[4] = 1; break;
	case 4:  octaveChB[6] = 1;  octaveChB[5] = 0;  octaveChB[4] = 0; break;
	case 5:  octaveChB[6] = 1;  octaveChB[5] = 0;  octaveChB[4] = 1; break;
	case 6:  octaveChB[6] = 1;  octaveChB[5] = 1;  octaveChB[4] = 0; break;
	case 7:  octaveChB[6] = 1;  octaveChB[5] = 1;  octaveChB[4] = 1; break;
	}
	for (int i = 0; i < 8; i++){octaveByte = bitWrite(octaveByte,i,octaveChB[i]);}
	loadDataByteToChip(octaveByte,1);
	break;


	case 5:
	switch(range)
	{
	case 0:  octaveChC[2] = 0;  octaveChC[1] = 0;  octaveChC[0] = 0; break;
	case 1:  octaveChC[2] = 0;  octaveChC[1] = 0;  octaveChC[0] = 1; break;
	case 2:  octaveChC[2] = 0;  octaveChC[1] = 1;  octaveChC[0] = 0; break;
	case 3:  octaveChC[2] = 0;  octaveChC[1] = 1;  octaveChC[0] = 1; break;
	case 4:  octaveChC[2] = 1;  octaveChC[1] = 0;  octaveChC[0] = 0; break;
	case 5:  octaveChC[2] = 1;  octaveChC[1] = 0;  octaveChC[0] = 1; break;
	case 6:  octaveChC[2] = 1;  octaveChC[1] = 1;  octaveChC[0] = 0; break;
	case 7:  octaveChC[2] = 1;  octaveChC[1] = 1;  octaveChC[0] = 1; break;
	}
	for (int i = 0; i < 8; i++){octaveByte = bitWrite(octaveByte,i,octaveChC[i]);}
	loadDataByteToChip(octaveByte,1);
	break;


	case 6:
	switch(range)
	{
	case 0:  octaveChC[6] = 0;  octaveChC[5] = 0;  octaveChC[4] = 0; break;
	case 1:  octaveChC[6] = 0;  octaveChC[5] = 0;  octaveChC[4] = 1; break;
	case 2:  octaveChC[6] = 0;  octaveChC[5] = 1;  octaveChC[4] = 0; break;
	case 3:  octaveChC[6] = 0;  octaveChC[5] = 1;  octaveChC[4] = 1; break;
	case 4:  octaveChC[6] = 1;  octaveChC[5] = 0;  octaveChC[4] = 0; break;
	case 5:  octaveChC[6] = 1;  octaveChC[5] = 0;  octaveChC[4] = 1; break;
	case 6:  octaveChC[6] = 1;  octaveChC[5] = 1;  octaveChC[4] = 0; break;
	case 7:  octaveChC[6] = 1;  octaveChC[5] = 1;  octaveChC[4] = 1; break;
	}
	for (int i = 0; i < 8; i++){ octaveByte = bitWrite(octaveByte,i,octaveChC[i]);}
	loadDataByteToChip(octaveByte,1);
	break;


	case 7:
	switch(range)
	{
	case 0:  octaveChD[2] = 0;  octaveChD[1] = 0;  octaveChD[0] = 0; break;
	case 1:  octaveChD[2] = 0;  octaveChD[1] = 0;  octaveChD[0] = 1; break;
	case 2:  octaveChD[2] = 0;  octaveChD[1] = 1;  octaveChD[0] = 0; break;
	case 3:  octaveChD[2] = 0;  octaveChD[1] = 1;  octaveChD[0] = 1; break;
	case 4:  octaveChD[2] = 1;  octaveChD[1] = 0;  octaveChD[0] = 0; break;
	case 5:  octaveChD[2] = 1;  octaveChD[1] = 0;  octaveChD[0] = 1; break;
	case 6:  octaveChD[2] = 1;  octaveChD[1] = 1;  octaveChD[0] = 0; break;
	case 7:  octaveChD[2] = 1;  octaveChD[1] = 1;  octaveChD[0] = 1; break;
	}
	for (int i = 0; i < 8; i++){octaveByte = bitWrite(octaveByte,i,octaveChD[i]);}
	loadDataByteToChip(octaveByte,2);
	break;


	case 8:
	switch(range)
	{
	case 0:  octaveChD[6] = 0;  octaveChD[5] = 0;  octaveChD[4] = 0; break;
	case 1:  octaveChD[6] = 0;  octaveChD[5] = 0;  octaveChD[4] = 1; break;
	case 2:  octaveChD[6] = 0;  octaveChD[5] = 1;  octaveChD[4] = 0; break;
	case 3:  octaveChD[6] = 0;  octaveChD[5] = 1;  octaveChD[4] = 1; break;
	case 4:  octaveChD[6] = 1;  octaveChD[5] = 0;  octaveChD[4] = 0; break;
	case 5:  octaveChD[6] = 1;  octaveChD[5] = 0;  octaveChD[4] = 1; break;
	case 6:  octaveChD[6] = 1;  octaveChD[5] = 1;  octaveChD[4] = 0; break;
	case 7:  octaveChD[6] = 1;  octaveChD[5] = 1;  octaveChD[4] = 1; break;
	}
	for (int i = 0; i < 8; i++){octaveByte = bitWrite(octaveByte,i,octaveChD[i]);}
	loadDataByteToChip(octaveByte,2);
	break;


	case 9:
	switch(range)
	{
	case 0:  octaveChE[2] = 0;  octaveChE[1] = 0;  octaveChE[0] = 0; break;
	case 1:  octaveChE[2] = 0;  octaveChE[1] = 0;  octaveChE[0] = 1; break;
	case 2:  octaveChE[2] = 0;  octaveChE[1] = 1;  octaveChE[0] = 0; break;
	case 3:  octaveChE[2] = 0;  octaveChE[1] = 1;  octaveChE[0] = 1; break;
	case 4:  octaveChE[2] = 1;  octaveChE[1] = 0;  octaveChE[0] = 0; break;
	case 5:  octaveChE[2] = 1;  octaveChE[1] = 0;  octaveChE[0] = 1; break;
	case 6:  octaveChE[2] = 1;  octaveChE[1] = 1;  octaveChE[0] = 0; break;
	case 7:  octaveChE[2] = 1;  octaveChE[1] = 1;  octaveChE[0] = 1; break;
	}
	for (int i = 0; i < 8; i++){octaveByte = bitWrite(octaveByte,i,octaveChE[i]);}
	loadDataByteToChip(octaveByte,2);//load byte to chip
	break;


	case 10:
	switch(range)
	{
	case 0:  octaveChE[6] = 0;  octaveChE[5] = 0;  octaveChE[4] = 0; break;
	case 1:  octaveChE[6] = 0;  octaveChE[5] = 0;  octaveChE[4] = 1; break;
	case 2:  octaveChE[6] = 0;  octaveChE[5] = 1;  octaveChE[4] = 0; break;
	case 3:  octaveChE[6] = 0;  octaveChE[5] = 1;  octaveChE[4] = 1; break;
	case 4:  octaveChE[6] = 1;  octaveChE[5] = 0;  octaveChE[4] = 0; break;
	case 5:  octaveChE[6] = 1;  octaveChE[5] = 0;  octaveChE[4] = 1; break;
	case 6:  octaveChE[6] = 1;  octaveChE[5] = 1;  octaveChE[4] = 0; break;
	case 7:  octaveChE[6] = 1;  octaveChE[5] = 1;  octaveChE[4] = 1; break;
	}
	for (int i = 0; i < 8; i++){octaveByte = bitWrite(octaveByte,i,octaveChE[i]);}
	loadDataByteToChip(octaveByte,2);
	break;


	case 11:
	switch(range)
	{
	case 0:  octaveChF[2] = 0;  octaveChF[1] = 0;  octaveChF[0] = 0; break;
	case 1:  octaveChF[2] = 0;  octaveChF[1] = 0;  octaveChF[0] = 1; break;
	case 2:  octaveChF[2] = 0;  octaveChF[1] = 1;  octaveChF[0] = 0; break;
	case 3:  octaveChF[2] = 0;  octaveChF[1] = 1;  octaveChF[0] = 1; break;
	case 4:  octaveChF[2] = 1;  octaveChF[1] = 0;  octaveChF[0] = 0; break;
	case 5:  octaveChF[2] = 1;  octaveChF[1] = 0;  octaveChF[0] = 1; break;
	case 6:  octaveChF[2] = 1;  octaveChF[1] = 1;  octaveChF[0] = 0; break;
	case 7:  octaveChF[2] = 1;  octaveChF[1] = 1;  octaveChF[0] = 1; break;
	}
	for (int i = 0; i < 8; i++){octaveByte = bitWrite(octaveByte,i,octaveChF[i]);}
	loadDataByteToChip(octaveByte,2);
	break;


	case 12:
	switch(range)
	{
	case 0:  octaveChF[6] = 0;  octaveChF[5] = 0;  octaveChF[4] = 0; break;
	case 1:  octaveChF[6] = 0;  octaveChF[5] = 0;  octaveChF[4] = 1; break;
	case 2:  octaveChF[6] = 0;  octaveChF[5] = 1;  octaveChF[4] = 0; break;
	case 3:  octaveChF[6] = 0;  octaveChF[5] = 1;  octaveChF[4] = 1; break;
	case 4:  octaveChF[6] = 1;  octaveChF[5] = 0;  octaveChF[4] = 0; break;
	case 5:  octaveChF[6] = 1;  octaveChF[5] = 0;  octaveChF[4] = 1; break;
	case 6:  octaveChF[6] = 1;  octaveChF[5] = 1;  octaveChF[4] = 0; break;
	case 7:  octaveChF[6] = 1;  octaveChF[5] = 1;  octaveChF[4] = 1; break;
	}
	for (int i = 0; i < 8; i++){octaveByte = bitWrite(octaveByte,i,octaveChF[i]);}
	loadDataByteToChip(octaveByte,2);//load byte to chip
	break;


	case 13:
	switch(range)
	{
	case 0:  octaveChG[2] = 0;  octaveChG[1] = 0;  octaveChG[0] = 0; break;
	case 1:  octaveChG[2] = 0;  octaveChG[1] = 0;  octaveChG[0] = 1; break;
	case 2:  octaveChG[2] = 0;  octaveChG[1] = 1;  octaveChG[0] = 0; break;
	case 3:  octaveChG[2] = 0;  octaveChG[1] = 1;  octaveChG[0] = 1; break;
	case 4:  octaveChG[2] = 1;  octaveChG[1] = 0;  octaveChG[0] = 0; break;
	case 5:  octaveChG[2] = 1;  octaveChG[1] = 0;  octaveChG[0] = 1; break;
	case 6:  octaveChG[2] = 1;  octaveChG[1] = 1;  octaveChG[0] = 0; break;
	case 7:  octaveChG[2] = 1;  octaveChG[1] = 1;  octaveChG[0] = 1; break;
	}
	for (int i = 0; i < 8; i++){octaveByte = bitWrite(octaveByte,i,octaveChG[i]);}
	loadDataByteToChip(octaveByte,3);
	break;


	case 14:
	switch(range)
	{
	case 0:  octaveChG[6] = 0;  octaveChG[5] = 0;  octaveChG[4] = 0; break;
	case 1:  octaveChG[6] = 0;  octaveChG[5] = 0;  octaveChG[4] = 1; break;
	case 2:  octaveChG[6] = 0;  octaveChG[5] = 1;  octaveChG[4] = 0; break;
	case 3:  octaveChG[6] = 0;  octaveChG[5] = 1;  octaveChG[4] = 1; break;
	case 4:  octaveChG[6] = 1;  octaveChG[5] = 0;  octaveChG[4] = 0; break;
	case 5:  octaveChG[6] = 1;  octaveChG[5] = 0;  octaveChG[4] = 1; break;
	case 6:  octaveChG[6] = 1;  octaveChG[5] = 1;  octaveChG[4] = 0; break;
	case 7:  octaveChG[6] = 1;  octaveChG[5] = 1;  octaveChG[4] = 1; break;
	}
	for (int i = 0; i < 8; i++){octaveByte = bitWrite(octaveByte,i,octaveChG[i]);}
	loadDataByteToChip(octaveByte,3);
	break;


	case 15:
	switch(range)
	{
	case 0:  octaveChH[2] = 0;  octaveChH[1] = 0;  octaveChH[0] = 0; break;
	case 1:  octaveChH[2] = 0;  octaveChH[1] = 0;  octaveChH[0] = 1; break;
	case 2:  octaveChH[2] = 0;  octaveChH[1] = 1;  octaveChH[0] = 0; break;
	case 3:  octaveChH[2] = 0;  octaveChH[1] = 1;  octaveChH[0] = 1; break;
	case 4:  octaveChH[2] = 1;  octaveChH[1] = 0;  octaveChH[0] = 0; break;
	case 5:  octaveChH[2] = 1;  octaveChH[1] = 0;  octaveChH[0] = 1; break;
	case 6:  octaveChH[2] = 1;  octaveChH[1] = 1;  octaveChH[0] = 0; break;
	case 7:  octaveChH[2] = 1;  octaveChH[1] = 1;  octaveChH[0] = 1; break;
	}
	for (int i = 0; i < 8; i++){ octaveByte = bitWrite(octaveByte,i,octaveChH[i]);}
	loadDataByteToChip(octaveByte,3);
	break;


	case 16:
	switch(range)
	{
	case 0:  octaveChH[6] = 0;  octaveChH[5] = 0;  octaveChH[4] = 0; break;
	case 1:  octaveChH[6] = 0;  octaveChH[5] = 0;  octaveChH[4] = 1; break;
	case 2:  octaveChH[6] = 0;  octaveChH[5] = 1;  octaveChH[4] = 0; break;
	case 3:  octaveChH[6] = 0;  octaveChH[5] = 1;  octaveChH[4] = 1; break;
	case 4:  octaveChH[6] = 1;  octaveChH[5] = 0;  octaveChH[4] = 0; break;
	case 5:  octaveChH[6] = 1;  octaveChH[5] = 0;  octaveChH[4] = 1; break;
	case 6:  octaveChH[6] = 1;  octaveChH[5] = 1;  octaveChH[4] = 0; break;
	case 7:  octaveChH[6] = 1;  octaveChH[5] = 1;  octaveChH[4] = 1; break;
	}
	for (int i = 0; i < 8; i++){ octaveByte = bitWrite(octaveByte,i,octaveChH[i]);}
	loadDataByteToChip(octaveByte,3);
	break;


	case 17:
	switch(range)
	{
	case 0:  octaveChI[2] = 0;  octaveChI[1] = 0;  octaveChI[0] = 0; break;
	case 1:  octaveChI[2] = 0;  octaveChI[1] = 0;  octaveChI[0] = 1; break;
	case 2:  octaveChI[2] = 0;  octaveChI[1] = 1;  octaveChI[0] = 0; break;
	case 3:  octaveChI[2] = 0;  octaveChI[1] = 1;  octaveChI[0] = 1; break;
	case 4:  octaveChI[2] = 1;  octaveChI[1] = 0;  octaveChI[0] = 0; break;
	case 5:  octaveChI[2] = 1;  octaveChI[1] = 0;  octaveChI[0] = 1; break;
	case 6:  octaveChI[2] = 1;  octaveChI[1] = 1;  octaveChI[0] = 0; break;
	case 7:  octaveChI[2] = 1;  octaveChI[1] = 1;  octaveChI[0] = 1; break;
	}
	for (int i = 0; i < 8; i++){ octaveByte = bitWrite(octaveByte,i,octaveChI[i]);}
	loadDataByteToChip(octaveByte,3);
	break;


	case 18:
	switch(range)
	{
	case 0:  octaveChI[6] = 0;  octaveChI[5] = 0;  octaveChI[4] = 0; break;
	case 1:  octaveChI[6] = 0;  octaveChI[5] = 0;  octaveChI[4] = 1; break;
	case 2:  octaveChI[6] = 0;  octaveChI[5] = 1;  octaveChI[4] = 0; break;
	case 3:  octaveChI[6] = 0;  octaveChI[5] = 1;  octaveChI[4] = 1; break;
	case 4:  octaveChI[6] = 1;  octaveChI[5] = 0;  octaveChI[4] = 0; break;
	case 5:  octaveChI[6] = 1;  octaveChI[5] = 0;  octaveChI[4] = 1; break;
	case 6:  octaveChI[6] = 1;  octaveChI[5] = 1;  octaveChI[4] = 0; break;
	case 7:  octaveChI[6] = 1;  octaveChI[5] = 1;  octaveChI[4] = 1; break;
	}
	for (int i = 0; i < 8; i++){octaveByte = bitWrite(octaveByte,i,octaveChI[i]);}
	loadDataByteToChip(octaveByte,3);
	break;
}

}

void SAA1099MEGA :: channelOctaveSet(byte ch, byte range)
{

	switch(ch)
{
	case 1:	loadAddressByteToChip(0x10,1);
	loadOctaveByteToChip(ch,range);
	break;
	
	case 2:
	loadAddressByteToChip(0x10,1);
	loadOctaveByteToChip(ch,range);
	break;
	
	case 3:
	loadAddressByteToChip(0x11,1);
	loadOctaveByteToChip(ch,range);
	break;
	
	case 4:
	loadAddressByteToChip(0x11,1);
	loadOctaveByteToChip(ch,range);
	break;
	
	case 5:
	loadAddressByteToChip(0x12,1);
	loadOctaveByteToChip(ch,range);
	break;
	
	case 6:
	loadAddressByteToChip(0x12,1);
	loadOctaveByteToChip(ch,range);
	break;
	
	case 7:
	loadAddressByteToChip(0x10,2);
	loadOctaveByteToChip(ch,range);
	break;
	
	case 8:
	loadAddressByteToChip(0x10,2);
	loadOctaveByteToChip(ch,range);
	break;
	
	case 9:
	loadAddressByteToChip(0x11,2);
	loadOctaveByteToChip(ch,range);
	break;
	
	case 10:
	loadAddressByteToChip(0x11,2);
	loadOctaveByteToChip(ch,range);
	break;
	
	case 11:
	loadAddressByteToChip(0x12,2);
	loadOctaveByteToChip(ch,range);
	break;
	
	case 12:
	loadAddressByteToChip(0x12,2);
	loadOctaveByteToChip(ch,range);
	break;
	
	case 13:
	loadAddressByteToChip(0x10,3);
	loadOctaveByteToChip(ch,range);
	break;
	
	case 14:
	loadAddressByteToChip(0x10,3);
	loadOctaveByteToChip(ch,range);
	break;
	
	case 15:
	loadAddressByteToChip(0x11,3);
	loadOctaveByteToChip(ch,range);
	break;
	
	case 16:
	loadAddressByteToChip(0x11,3);
	loadOctaveByteToChip(ch,range);
	break;
	
	case 17:
	loadAddressByteToChip(0x12,3);
	loadOctaveByteToChip(ch,range);
	break;
	
	case 18:
	loadAddressByteToChip(0x12,3);
	loadOctaveByteToChip(ch,range);
	break;

}
}

void SAA1099MEGA :: tuneEeprom()
{
	static bool setSerialOutput = 0;
	static byte serialIn = 0;

	tunepos = constrain(tunepos,1,12);

	c  = constrain(c ,0,255);
	cs = constrain(cs,0,255);
	d  = constrain(d ,0,255);
	ds = constrain(ds,0,255);
	e  = constrain(e ,0,255);
	f  = constrain(f ,0,255);
	fs = constrain(fs,0,255);
	g  = constrain(g ,0,255);
	gs = constrain(gs,0,255);
	a  = constrain(a ,0,255);
	as = constrain(as,0,255);
	b  = constrain(b ,0,255);


	if(setSerialOutput == 0)//set up serial port and enable channel
	{
	Serial.begin(9600);
	setSerialOutput = 1;
	channelEnableSet(1,1);
	channelOctaveSet(1,3);
	printNotes();
	}

	if(Serial.available())//read bytes coming from serial port
	{
	serialIn = Serial.read();
	}


	switch(serialIn)
	{
	case 'p':// note to tune up
	tunepos ++;
	serialIn = 0;
	printNotes();
	break;


	case 'o':// note to tune down
	tunepos --;
	serialIn = 0;
	printNotes();
	break;


	case '='://pitch up
	serialIn = 0;
	switch (tunepos)
	{
	case 1:		b  ++;  printNotes();   break;
	case 2:		c  ++;	printNotes();	break;
	case 3:		cs ++;	printNotes();	break;
	case 4:		d  ++;	printNotes();	break;
	case 5:		ds ++;  printNotes();	break;
	case 6:		e  ++;	printNotes();	break;
	case 7:		f  ++;	printNotes();	break;
	case 8:		fs ++;	printNotes();	break;
	case 9: 	g  ++;	printNotes();	break;
	case 10:	gs ++;	printNotes();	break;
	case 11:	a  ++;	printNotes();	break;
	case 12:	as ++;	printNotes();	break;
	}
	break;


	case '-'://pitch down
	serialIn = 0;
	switch (tunepos)
	{
	case 1:		b  --;	printNotes();	break;
	case 2:		c  --;	printNotes();	break;
	case 3:		cs --;	printNotes();	break;
	case 4:		d  --;	printNotes();	break;
	case 5:		ds --;	printNotes();	break;
	case 6:		e  --;	printNotes();	break;
	case 7:		f  --;	printNotes();	break;
	case 8:		fs --;	printNotes();	break;
	case 9:		g  --;	printNotes();	break;
	case 10:	gs --;	printNotes();	break;
	case 11:	a  --;	printNotes();	break;
	case 12:	as --;	printNotes();	break;
	}
	break;


	case 's'://save to eeprom
	Serial.print("SAVED TO EEPROM");
	delay(1000);
	EEPROM.write(0,b);
	EEPROM.write(1,c);
	EEPROM.write(2,cs);
	EEPROM.write(3,d);
	EEPROM.write(4,ds);
	EEPROM.write(5,e);
	EEPROM.write(6,f);
	EEPROM.write(7,fs);
	EEPROM.write(8,g);
	EEPROM.write(9,gs);
	EEPROM.write(10,a);
	EEPROM.write(11,as);
	Serial.println();
	serialIn = 0;
	break;
	}

	switch (tunepos)// play pitch byte
	{
	case 1:	 channelPitchSet(1,b);	break;
	case 2:	 channelPitchSet(1,c);	break;
	case 3:	 channelPitchSet(1,cs);	break;
	case 4:	 channelPitchSet(1,d);	break;
	case 5:	 channelPitchSet(1,ds);	break;
	case 6:	 channelPitchSet(1,e);	break;
	case 7:	 channelPitchSet(1,f);	break;
	case 8:	 channelPitchSet(1,fs);	break;
	case 9:	 channelPitchSet(1,g);	break;
	case 10: channelPitchSet(1,gs);	break;
	case 11: channelPitchSet(1,a);	break;
	case 12: channelPitchSet(1,as);	break;
	}


}

void SAA1099MEGA :: defaultTuneEeprom()
{


 display.clearDisplay();  // Clear the display so we can refresh
//////
  display.setCursor(0, 0);  // (x,y)
  display.println("DEFAULT EEPROM TUNE");  // Text or value to print

 ////// 
  display.display();  // Print everything we set previously 
  
	EEPROM.write(0,6);//b
	EEPROM.write(1,33);//c
	EEPROM.write(2,60);//cs
	EEPROM.write(3,85);//d
	EEPROM.write(4,109);//ds
	EEPROM.write(5,132);//e
	EEPROM.write(6,153);//f
	EEPROM.write(7,173);//fs
	EEPROM.write(8,192);//g
	EEPROM.write(9,210);//gs
	EEPROM.write(10,227);//a
	EEPROM.write(11,243);//as
}

void SAA1099MEGA :: printNotes()
{
    if(tunepos > 0 && tunepos < 13)
	{
		
	 display.clearDisplay();  // Clear the display so we can refresh
//////
  
  
    display.setCursor(0, 0);  // (x,y)
    display.println("TUNE TO B  ");  // Text or value to print
	
    display.setCursor(0, 10);  // (x,y)
    display.println("EEPROM VALUE = ");  // Text or value to print

    display.setCursor(90, 10);  // (x,y)
    display.println(b);  // Text or value to print



 ////// 
  display.display();  // Print everything we set previously 	
		
	Serial.print("  B = ");
	Serial.print(b);
	Serial.print("  C = ");
	Serial.print(c);
	Serial.print("  C# = ");
	Serial.print(cs);
	Serial.print("  D = ");
	Serial.print(d);
	Serial.print("  D# = ");
	Serial.print(ds);
	Serial.print("  E = ");
	Serial.print(e);
	Serial.print("  F = ");
	Serial.print(f);
	Serial.print("  F# = ");
	Serial.print(fs);
	Serial.print("  G = ");
	Serial.print(g);
	Serial.print("  GS = ");
	Serial.print(gs);
	Serial.print("  A = ");
	Serial.print(a);
	Serial.print("  A# = ");
	Serial.print(as);
	Serial.print("    Tuning note = ");
	switch(tunepos)
	{
	case 1:	 Serial.print(" B ");	break;
	case 2:	 Serial.print(" C ");	break;
	case 3:	 Serial.print(" C# ");	break;
	case 4:  Serial.print(" D ");	break;
	case 5:	 Serial.print(" D# ");	break;
	case 6:	 Serial.print(" E ");	break;
	case 7:  Serial.print(" F ");	break;
	case 8:	 Serial.print(" F# ");	break;
	case 9:	 Serial.print(" G ");	break;
	case 10: Serial.print(" G# ");	break;
	case 11: Serial.print(" A ");	break;
	case 12: Serial.print(" A# ");	break;
	}

	Serial.print("   KEYS =  (- +) pitch up/down  (p o) note up/down  (s)  Save");
	Serial.println();
    }



}

void SAA1099MEGA :: notePlay(byte channel, byte midinote, bool enable)
{
	
	
	
	switch(midinote)//octave is 1 higher  0 = 1   1 = 2 etc.....
	{
	case 23:  channelOctaveSet(channel,0);channelPitchSet(channel,b) ;channelEnableSet(channel,enable);break;
	case 24:  channelOctaveSet(channel,0);channelPitchSet(channel,c) ;channelEnableSet(channel,enable);break;
	case 25:  channelOctaveSet(channel,0);channelPitchSet(channel,cs);channelEnableSet(channel,enable);break;
	case 26:  channelOctaveSet(channel,0);channelPitchSet(channel,d) ;channelEnableSet(channel,enable);break;
	case 27:  channelOctaveSet(channel,0);channelPitchSet(channel,ds);channelEnableSet(channel,enable);break;
	case 28:  channelOctaveSet(channel,0);channelPitchSet(channel,e) ;channelEnableSet(channel,enable);break;
	case 29:  channelOctaveSet(channel,0);channelPitchSet(channel,f) ;channelEnableSet(channel,enable);break;
	case 30:  channelOctaveSet(channel,0);channelPitchSet(channel,fs);channelEnableSet(channel,enable);break;
	case 31:  channelOctaveSet(channel,0);channelPitchSet(channel,g) ;channelEnableSet(channel,enable);break;
	case 32:  channelOctaveSet(channel,0);channelPitchSet(channel,gs);channelEnableSet(channel,enable);break;
	case 33:  channelOctaveSet(channel,0);channelPitchSet(channel,a) ;channelEnableSet(channel,enable);break;
	case 34:  channelOctaveSet(channel,0);channelPitchSet(channel,as);channelEnableSet(channel,enable);break;
	case 35:  channelOctaveSet(channel,1);channelPitchSet(channel,b) ;channelEnableSet(channel,enable);break;
	case 36:  channelOctaveSet(channel,1);channelPitchSet(channel,c) ;channelEnableSet(channel,enable);break;
	case 37:  channelOctaveSet(channel,1);channelPitchSet(channel,cs);channelEnableSet(channel,enable);break;
	case 38:  channelOctaveSet(channel,1);channelPitchSet(channel,d) ;channelEnableSet(channel,enable);break;
	case 39:  channelOctaveSet(channel,1);channelPitchSet(channel,ds);channelEnableSet(channel,enable);break;
	case 40:  channelOctaveSet(channel,1);channelPitchSet(channel,e) ;channelEnableSet(channel,enable);break;
	case 41:  channelOctaveSet(channel,1);channelPitchSet(channel,f) ;channelEnableSet(channel,enable);break;
	case 42:  channelOctaveSet(channel,1);channelPitchSet(channel,fs);channelEnableSet(channel,enable);break;
	case 43:  channelOctaveSet(channel,1);channelPitchSet(channel,g) ;channelEnableSet(channel,enable);break;
	case 44:  channelOctaveSet(channel,1);channelPitchSet(channel,gs);channelEnableSet(channel,enable);break;
	case 45:  channelOctaveSet(channel,1);channelPitchSet(channel,a) ;channelEnableSet(channel,enable);break;
	case 46:  channelOctaveSet(channel,1);channelPitchSet(channel,as);channelEnableSet(channel,enable);break;
	case 47:  channelOctaveSet(channel,2);channelPitchSet(channel,b) ;channelEnableSet(channel,enable);break;
	case 48:  channelOctaveSet(channel,2);channelPitchSet(channel,c) ;channelEnableSet(channel,enable);break;
	case 49:  channelOctaveSet(channel,2);channelPitchSet(channel,cs);channelEnableSet(channel,enable);break;
	case 50:  channelOctaveSet(channel,2);channelPitchSet(channel,d) ;channelEnableSet(channel,enable);break;
	case 51:  channelOctaveSet(channel,2);channelPitchSet(channel,ds);channelEnableSet(channel,enable);break;
	case 52:  channelOctaveSet(channel,2);channelPitchSet(channel,e) ;channelEnableSet(channel,enable);break;
	case 53:  channelOctaveSet(channel,2);channelPitchSet(channel,f) ;channelEnableSet(channel,enable);break;
	case 54:  channelOctaveSet(channel,2);channelPitchSet(channel,fs);channelEnableSet(channel,enable);break;
	case 55:  channelOctaveSet(channel,2);channelPitchSet(channel,g) ;channelEnableSet(channel,enable);break;
	case 56:  channelOctaveSet(channel,2);channelPitchSet(channel,gs);channelEnableSet(channel,enable);break;
	case 57:  channelOctaveSet(channel,2);channelPitchSet(channel,a) ;channelEnableSet(channel,enable);break;
	case 58:  channelOctaveSet(channel,2);channelPitchSet(channel,as);channelEnableSet(channel,enable);break;
	case 59:  channelOctaveSet(channel,3);channelPitchSet(channel,b) ;channelEnableSet(channel,enable);break;
	case 60:  channelOctaveSet(channel,3);channelPitchSet(channel,c) ;channelEnableSet(channel,enable);break;
	case 61:  channelOctaveSet(channel,3);channelPitchSet(channel,cs);channelEnableSet(channel,enable);break;
	case 62:  channelOctaveSet(channel,3);channelPitchSet(channel,d) ;channelEnableSet(channel,enable);break;
	case 63:  channelOctaveSet(channel,3);channelPitchSet(channel,ds);channelEnableSet(channel,enable);break;
	case 64:  channelOctaveSet(channel,3);channelPitchSet(channel,e) ;channelEnableSet(channel,enable);break;
	case 65:  channelOctaveSet(channel,3);channelPitchSet(channel,f) ;channelEnableSet(channel,enable);break;
	case 66:  channelOctaveSet(channel,3);channelPitchSet(channel,fs);channelEnableSet(channel,enable);break;
	case 67:  channelOctaveSet(channel,3);channelPitchSet(channel,g) ;channelEnableSet(channel,enable);break;
	case 68:  channelOctaveSet(channel,3);channelPitchSet(channel,gs);channelEnableSet(channel,enable);break;
	case 69:  channelOctaveSet(channel,3);channelPitchSet(channel,a) ;channelEnableSet(channel,enable);break;
	case 70:  channelOctaveSet(channel,3);channelPitchSet(channel,as);channelEnableSet(channel,enable);break;
	case 71:  channelOctaveSet(channel,4);channelPitchSet(channel,b) ;channelEnableSet(channel,enable);break;
	case 72:  channelOctaveSet(channel,4);channelPitchSet(channel,c) ;channelEnableSet(channel,enable);break;//c5
	case 73:  channelOctaveSet(channel,4);channelPitchSet(channel,cs);channelEnableSet(channel,enable);break;
	case 74:  channelOctaveSet(channel,4);channelPitchSet(channel,d) ;channelEnableSet(channel,enable);break;
	case 75:  channelOctaveSet(channel,4);channelPitchSet(channel,ds);channelEnableSet(channel,enable);break;
	case 76:  channelOctaveSet(channel,4);channelPitchSet(channel,e) ;channelEnableSet(channel,enable);break;
	case 77:  channelOctaveSet(channel,4);channelPitchSet(channel,f) ;channelEnableSet(channel,enable);break;
	case 78:  channelOctaveSet(channel,4);channelPitchSet(channel,fs);channelEnableSet(channel,enable);break;
	case 79:  channelOctaveSet(channel,4);channelPitchSet(channel,g) ;channelEnableSet(channel,enable);break;
	case 80:  channelOctaveSet(channel,4);channelPitchSet(channel,gs);channelEnableSet(channel,enable);break;
	case 81:  channelOctaveSet(channel,4);channelPitchSet(channel,a) ;channelEnableSet(channel,enable);break;
	case 82:  channelOctaveSet(channel,4);channelPitchSet(channel,as);channelEnableSet(channel,enable);break;
	case 83:  channelOctaveSet(channel,5);channelPitchSet(channel,b) ;channelEnableSet(channel,enable);break;
	case 84:  channelOctaveSet(channel,5);channelPitchSet(channel,c) ;channelEnableSet(channel,enable);break;//c6
	case 85:  channelOctaveSet(channel,5);channelPitchSet(channel,cs);channelEnableSet(channel,enable);break;
	case 86:  channelOctaveSet(channel,5);channelPitchSet(channel,d) ;channelEnableSet(channel,enable);break;
	case 87:  channelOctaveSet(channel,5);channelPitchSet(channel,ds);channelEnableSet(channel,enable);break;
	case 88:  channelOctaveSet(channel,5);channelPitchSet(channel,e) ;channelEnableSet(channel,enable);break;
	case 89:  channelOctaveSet(channel,5);channelPitchSet(channel,f) ;channelEnableSet(channel,enable);break;
	case 90:  channelOctaveSet(channel,5);channelPitchSet(channel,fs);channelEnableSet(channel,enable);break;
	case 91:  channelOctaveSet(channel,5);channelPitchSet(channel,g) ;channelEnableSet(channel,enable);break;
	case 92:  channelOctaveSet(channel,5);channelPitchSet(channel,gs);channelEnableSet(channel,enable);break;
	case 93:  channelOctaveSet(channel,5);channelPitchSet(channel,a) ;channelEnableSet(channel,enable);break;
	case 94:  channelOctaveSet(channel,5);channelPitchSet(channel,as);channelEnableSet(channel,enable);break;
	case 95:  channelOctaveSet(channel,6);channelPitchSet(channel,b) ;channelEnableSet(channel,enable);break;
	case 96:  channelOctaveSet(channel,6);channelPitchSet(channel,c) ;channelEnableSet(channel,enable);break;//c7
	case 97:  channelOctaveSet(channel,6);channelPitchSet(channel,cs);channelEnableSet(channel,enable);break;
	case 98:  channelOctaveSet(channel,6);channelPitchSet(channel,d) ;channelEnableSet(channel,enable);break;
	case 99:  channelOctaveSet(channel,6);channelPitchSet(channel,ds);channelEnableSet(channel,enable);break;
	case 100: channelOctaveSet(channel,6);channelPitchSet(channel,e) ;channelEnableSet(channel,enable);break;
	case 101: channelOctaveSet(channel,6);channelPitchSet(channel,f) ;channelEnableSet(channel,enable);break;
	case 102: channelOctaveSet(channel,6);channelPitchSet(channel,fs);channelEnableSet(channel,enable);break;
	case 103: channelOctaveSet(channel,6);channelPitchSet(channel,g) ;channelEnableSet(channel,enable);break;
	case 104: channelOctaveSet(channel,6);channelPitchSet(channel,gs);channelEnableSet(channel,enable);break;
	case 105: channelOctaveSet(channel,6);channelPitchSet(channel,a) ;channelEnableSet(channel,enable);break;
	case 106: channelOctaveSet(channel,6);channelPitchSet(channel,as);channelEnableSet(channel,enable);break;
	case 107: channelOctaveSet(channel,7);channelPitchSet(channel,b) ;channelEnableSet(channel,enable);break;
	case 108: channelOctaveSet(channel,7);channelPitchSet(channel,c) ;channelEnableSet(channel,enable);break;//c8
	case 109: channelOctaveSet(channel,7);channelPitchSet(channel,cs);channelEnableSet(channel,enable);break;
	case 110: channelOctaveSet(channel,7);channelPitchSet(channel,d) ;channelEnableSet(channel,enable);break;
	case 111: channelOctaveSet(channel,7);channelPitchSet(channel,ds);channelEnableSet(channel,enable);break;
	case 112: channelOctaveSet(channel,7);channelPitchSet(channel,e) ;channelEnableSet(channel,enable);break;
	case 113: channelOctaveSet(channel,7);channelPitchSet(channel,f) ;channelEnableSet(channel,enable);break;
	case 114: channelOctaveSet(channel,7);channelPitchSet(channel,fs);channelEnableSet(channel,enable);break;
	case 115: channelOctaveSet(channel,7);channelPitchSet(channel,g) ;channelEnableSet(channel,enable);break;
	case 116: channelOctaveSet(channel,7);channelPitchSet(channel,gs);channelEnableSet(channel,enable);break;
	case 117: channelOctaveSet(channel,7);channelPitchSet(channel,a) ;channelEnableSet(channel,enable);break;
	case 118: channelOctaveSet(channel,7);channelPitchSet(channel,as);channelEnableSet(channel,enable);break;
	case 119: channelOctaveSet(channel,8);channelPitchSet(channel,b) ;channelEnableSet(channel,enable);break;
	case 120: channelOctaveSet(channel,8);channelPitchSet(channel,c) ;channelEnableSet(channel,enable);break;//c8
	case 121: channelOctaveSet(channel,8);channelPitchSet(channel,cs);channelEnableSet(channel,enable);break;
	case 122: channelOctaveSet(channel,8);channelPitchSet(channel,d) ;channelEnableSet(channel,enable);break;
	case 123: channelOctaveSet(channel,8);channelPitchSet(channel,ds);channelEnableSet(channel,enable);break;
	case 124: channelOctaveSet(channel,8);channelPitchSet(channel,e) ;channelEnableSet(channel,enable);break;
	case 125: channelOctaveSet(channel,8);channelPitchSet(channel,f) ;channelEnableSet(channel,enable);break;
	case 126: channelOctaveSet(channel,8);channelPitchSet(channel,fs);channelEnableSet(channel,enable);break;
	case 127: channelOctaveSet(channel,8);channelPitchSet(channel,g) ;channelEnableSet(channel,enable);break;

	}

}

void SAA1099MEGA :: readMidiData()  
{
	////////////////////////////////////////////////////////////////////
	static int x = 0;
	if(x == 0)
	{
 display.clearDisplay();  // Clear the display so we can refresh
//////
  display.setCursor(0, 0);  // (x,y)
  display.println("READING MIDI PORT....");  // Text or value to print
  display.setCursor(22, 10);  // (x,y)
  display.println("OPTICAL PORT 2");  // Text or value to print
  display.setCursor(22, 20);  // (x,y)
  display.println("ALL CHANNELS");  // Text or value to print
 ////// 
  display.display();  // Print everything we set previously 
  x = 1;
	}//////////////////////////////////////////////////////////////////
	
	
	
	
	static byte controll = 0;
	static byte pitch    = 0;
	static byte velocity = 0;	
    static const long interval1 = 50; 
	static const long interval2 = 50; 
	static const long interval3 = 50; 
	static const long interval4 = 50; 
	static const long interval5 = 50; 
	static const long interval6 = 50; 
	static const long interval7 = 50; 
	static const long interval8 = 50; 
	static const long interval9 = 150;
	static const long interval10 = 50;
	static const long interval11 = 50;
	static const long interval12 = 50;
	static const long interval13 = 50;
    unsigned long currentMillis = millis();
	
	
 if (currentMillis - starttime1 >= interval1 && timeren1 == 1) //35 kick drum timer
   {
    starttime1 = currentMillis;
    noisePlay(35,0);
	timeren1 = 0;
	}
	
 if (currentMillis - starttime2 >= interval2 && timeren2 == 1) //36 kick drum timer
   {
    starttime2 = currentMillis;
    noisePlay(36,0);
	timeren2 = 0;
	}
	
 if (currentMillis - starttime3 >= interval3 && timeren3 == 1) //38 snare drum timer
   {
    starttime3 = currentMillis;
    noisePlay(38,0);
	timeren3 = 0;
	
	}
	
 if (currentMillis - starttime4 >= interval4 && timeren4 == 1) //40 snare drum timer
   {
    starttime4 = currentMillis;
    noisePlay(40,0);
	timeren4 = 0;
	
	}
	
	
 if (currentMillis - starttime5 >= interval5 && timeren5 == 1) //41 toms 1 timer
   {	
	starttime5 = currentMillis;
    noisePlay(41,0);
	timeren5 = 0;
   }
   
   
 if (currentMillis - starttime6 >= interval6 && timeren6 == 1) //42 hi hat closed drum timer
   {
    starttime6 = currentMillis;
    noisePlay(42,0);
	timeren6 = 0;
	
	}
	
		
 if (currentMillis - starttime7 >= interval7 && timeren7 == 1) //43 toms 2 timer
   {
    starttime7 = currentMillis;
    noisePlay(43,0);
	timeren7 = 0;
	
	}
	
 if (currentMillis - starttime8 >= interval8 && timeren8 == 1) //44 hi hat pedal drum timer
   {	
         starttime8 = currentMillis;
    noisePlay(44,0);
	timeren8 = 0;
	
	}
 if (currentMillis - starttime9 >= interval9 && timeren9 == 1) //45 toms 3 timer
   {
    starttime9 = currentMillis;
    noisePlay(45,0);
	timeren9 = 0;
	
	}
	
 if (currentMillis - starttime10 >= interval10 && timeren10 == 1) //46 hi hat open drum timer
  {	
      starttime10 = currentMillis;
    noisePlay(46,0);
	timeren10 = 0;
	
	}
	
 if (currentMillis - starttime11 >= interval11 && timeren11 == 1) //47 toms 4 timer
   {
    starttime11 = currentMillis;
    noisePlay(47,0);
	timeren11 = 0;
	
	}
	
	
 if (currentMillis - starttime12 >= interval12 && timeren12 == 1) //48 toms 5 timer
   {
    starttime12 = currentMillis;
    noisePlay(48,0);
	timeren12 = 0;
	
	}
	
	
 if (currentMillis - starttime13 >= interval13 && timeren13 == 1) //50 toms 6 timer
   {
    starttime13 = currentMillis;
    noisePlay(50,0);
	timeren13 = 0;
	
	}
	
	


	



	
	
	if	(Serial2.available()>=3)//midi input
	{
		
		
		
		
    digitalWrite(13,1);
    controll =  Serial2.read();	

   
	
  
	if(controll > 175 && controll < 192)//volume
	{
		
	pitch    = Serial2.read(); 
	velocity = Serial2.read();	
	
	if(pitch == 120)
	{
		
		chOn1 = 0; 
		chOn2 = 0; 
		chOn3 = 0; 
		chOn4 = 0; 
		chOn5 = 0; 
		chOn6 = 0; 
		chOn7 = 0; 
		chOn8 = 0; 
		chOn9 = 0; 
		chOn10 = 0;
		chOn11 = 0;
		chOn12 = 0;
		chOn13 = 0;
		chOn14 = 0;
		chOn15 = 0;
		chOn16 = 0;
		
		
		
		for(int i = 0; i < 18; i++)
		{
			channelEnableSet(i,0);
			
			
		}
		
		
	}

		if(pitch == 7)
		{
		switch (controll)
		{
			case 176: volume(1 , velocity); break;
			case 177: volume(2 , velocity); break;
			case 178: volume(3 , velocity); break;
			case 179: volume(4 , velocity); break;
			case 180: volume(5 , velocity); break;
			case 181: volume(6 , velocity); break;
			case 182: volume(7 , velocity); break;
			case 183: volume(8 , velocity); break;
			case 184: volume(9 , velocity); break;
			case 185: volume(10,velocity); break;
			case 186: volume(11,velocity); break;
			case 187: volume(12,velocity); break;
			case 189: volume(14,velocity); break;
			case 190: volume(15,velocity); break;
		
		}
		
		}
	}
	
    if(controll > 127 && controll < 160)//note on/off
	{

	pitch    = Serial2.read(); 
	velocity = Serial2.read();
	Serial1.write(controll);
	Serial1.write(pitch);
	Serial1.write(velocity);
   
	}
	   
	switch(controll)
	{
    case 128:midiNoteOff(1, pitch);break;
    case 129:midiNoteOff(2, pitch);break;
    case 130:midiNoteOff(3, pitch);break;
    case 131:midiNoteOff(4, pitch);break;
    case 132:midiNoteOff(5, pitch);break;
    case 133:midiNoteOff(6, pitch);break;
    case 134:midiNoteOff(7, pitch);break;
    case 135:midiNoteOff(8, pitch);break;
    case 136:midiNoteOff(9, pitch);break;
    case 137:drumsOff(pitch);break;
    case 138:midiNoteOff(11,pitch);break;
    case 139:midiNoteOff(12,pitch);break;
    case 140:midiNoteOff(13,pitch);break;
    case 141:midiNoteOff(14,pitch);break;
    case 142:midiNoteOff(15,pitch);break;
    case 143:midiNoteOff(16,pitch);break;
	
    case 144:midiNoteOn(1, pitch,velocity);break;
    case 145:midiNoteOn(2, pitch,velocity);break;
    case 146:midiNoteOn(3, pitch,velocity);break;
    case 147:midiNoteOn(4, pitch,velocity);break;
    case 148:midiNoteOn(5, pitch,velocity);break;
    case 149:midiNoteOn(6, pitch,velocity);break;
    case 150:midiNoteOn(7, pitch,velocity);break;
    case 151:midiNoteOn(8, pitch,velocity);break;
    case 152:midiNoteOn(9, pitch,velocity);break;
    case 153:drumsOn(pitch,velocity);break;
    case 154:midiNoteOn(11,pitch,velocity);break;
    case 155:midiNoteOn(12,pitch,velocity);break;
    case 156:midiNoteOn(13,pitch,velocity);break;
    case 157:midiNoteOn(14,pitch,velocity);break;
    case 158:midiNoteOn(15,pitch,velocity);break;
	case 159:midiNoteOn(16,pitch,velocity);break;}
}
    digitalWrite(13,0);
}


void SAA1099MEGA :: midiNoteOn(byte channel, byte note,byte velocity)
{
while(1)
{
if(chOn1 == 0){notePlay(1,note,1);   chOnPitch1  = note;chOn1  = 1;  break;}
if(chOn2 == 0){notePlay(2,note,1);   chOnPitch2  = note;chOn2  = 1;  break;}
if(chOn3 == 0){notePlay(3,note,1);   chOnPitch3  = note;chOn3  = 1;  break;}
if(chOn4 == 0){notePlay(4,note,1);   chOnPitch4  = note;chOn4  = 1;  break;}
if(chOn5 == 0){notePlay(5,note,1);   chOnPitch5  = note;chOn5  = 1;  break;}
if(chOn6 == 0){notePlay(6,note,1);   chOnPitch6  = note;chOn6  = 1;  break;}
if(chOn7 == 0){notePlay(7,note,1);   chOnPitch7  = note;chOn7  = 1;  break;}
if(chOn8 == 0){notePlay(8,note,1);   chOnPitch8  = note;chOn8  = 1;  break;}
if(chOn9 == 0){notePlay(9,note,1);   chOnPitch9  = note;chOn9  = 1;  break;}
if(chOn10 == 0){notePlay(10,note,1); chOnPitch10 = note;chOn10 = 1; break; }
if(chOn11 == 0){notePlay(11,note,1); chOnPitch11 = note;chOn11 = 1; break; }
if(chOn12 == 0){notePlay(12,note,1); chOnPitch12 = note;chOn12 = 1; break; }
if(chOn13 == 0){notePlay(13,note,1); chOnPitch13 = note;chOn13 = 1; break; }
if(chOn14 == 0){notePlay(14,note,1); chOnPitch14 = note;chOn14 = 1; break; }
if(chOn15 == 0){notePlay(15,note,1); chOnPitch15 = note;chOn15 = 1; break; }
if(chOn16 == 0){notePlay(16,note,1); chOnPitch16 = note;chOn16 = 1; break; }
break;
}  

if(velocity == 0)
{

if(chOn1  == 1&& note == chOnPitch1 ){channelEnableSet(1,0); chOn1  = 0;chOnPitch1  = 0;}
if(chOn2  == 1&& note == chOnPitch2 ){channelEnableSet(2,0); chOn2  = 0;chOnPitch2  = 0;}
if(chOn3  == 1&& note == chOnPitch3 ){channelEnableSet(3,0); chOn3  = 0;chOnPitch3  = 0;}
if(chOn4  == 1&& note == chOnPitch4 ){channelEnableSet(4,0); chOn4  = 0;chOnPitch4  = 0;}
if(chOn5  == 1&& note == chOnPitch5 ){channelEnableSet(5,0); chOn5  = 0;chOnPitch5  = 0;}
if(chOn6  == 1&& note == chOnPitch6 ){channelEnableSet(6,0); chOn6  = 0;chOnPitch6  = 0;}
if(chOn7  == 1&& note == chOnPitch7 ){channelEnableSet(7,0); chOn7  = 0;chOnPitch7  = 0;}
if(chOn8  == 1&& note == chOnPitch8 ){channelEnableSet(8,0); chOn8  = 0;chOnPitch8  = 0;}
if(chOn9  == 1&& note == chOnPitch9 ){channelEnableSet(9,0); chOn9  = 0;chOnPitch9  = 0;}
if(chOn10 == 1&& note == chOnPitch10){channelEnableSet(10,0);chOn10 = 0;chOnPitch10 = 0;}
if(chOn11 == 1&& note == chOnPitch11){channelEnableSet(11,0);chOn11 = 0;chOnPitch11 = 0;}
if(chOn12 == 1&& note == chOnPitch12){channelEnableSet(12,0);chOn12 = 0;chOnPitch12 = 0;}
if(chOn13 == 1&& note == chOnPitch13){channelEnableSet(13,0);chOn13 = 0;chOnPitch13 = 0;}
if(chOn14 == 1&& note == chOnPitch14){channelEnableSet(14,0);chOn14 = 0;chOnPitch14 = 0;}
if(chOn15 == 1&& note == chOnPitch15){channelEnableSet(15,0);chOn15 = 0;chOnPitch15 = 0;}
if(chOn16 == 1&& note == chOnPitch16){channelEnableSet(16,0);chOn16 = 0;chOnPitch16 = 0;}
}
}

void SAA1099MEGA :: midiNoteOff(byte channel, byte note)
{
if(note == chOnPitch1){channelEnableSet(1,0);   chOn1 = 0; chOnPitch1  = 0;}
if(note == chOnPitch2){channelEnableSet(2,0);   chOn2 = 0; chOnPitch2  = 0;}
if(note == chOnPitch3){channelEnableSet(3,0);   chOn3 = 0; chOnPitch3  = 0;}
if(note == chOnPitch4){channelEnableSet(4,0);   chOn4 = 0; chOnPitch4  = 0;}
if(note == chOnPitch5){channelEnableSet(5,0);   chOn5 = 0; chOnPitch5  = 0;}
if(note == chOnPitch6){channelEnableSet(6,0);   chOn6 = 0; chOnPitch6  = 0;}
if(note == chOnPitch7){channelEnableSet(7,0);   chOn7 = 0; chOnPitch7  = 0;}
if(note == chOnPitch8){channelEnableSet(8,0);   chOn8 = 0; chOnPitch8  = 0;}
if(note == chOnPitch9){channelEnableSet(9,0);   chOn9 = 0; chOnPitch9  = 0;}
if(note == chOnPitch10){channelEnableSet(10,0); chOn10 = 0;chOnPitch10 = 0;}
if(note == chOnPitch11){channelEnableSet(11,0); chOn11 = 0;chOnPitch11 = 0;}
if(note == chOnPitch12){channelEnableSet(12,0); chOn12 = 0;chOnPitch12 = 0;}
if(note == chOnPitch13){channelEnableSet(13,0); chOn13 = 0;chOnPitch13 = 0;}
if(note == chOnPitch14){channelEnableSet(14,0); chOn14 = 0;chOnPitch14 = 0;}
if(note == chOnPitch15){channelEnableSet(15,0); chOn15 = 0;chOnPitch15 = 0;}
if(note == chOnPitch16){channelEnableSet(16,0); chOn16 = 0;chOnPitch16 = 0;}
}


void SAA1099MEGA :: noisePlay(byte note, byte en)
{

switch(note)
{
	case 35:channelPitchSet(13,5); channelOctaveSet(13,3); channelEnableSet(19,en);break;//gen 1 acoustic kick
	case 36:channelPitchSet(13,5); channelOctaveSet(13,3); channelEnableSet(19,en);break;//gen 1 electric kick
	case 38:channelPitchSet(13,150); channelOctaveSet(13,6); channelEnableSet(19,en);break;//gen 1 acoustic snare
	case 40:channelPitchSet(13,150); channelOctaveSet(13,6); channelEnableSet(19,en);break;//gen 1 electric snare
	case 41:channelPitchSet(13,0); channelOctaveSet(13,4); channelEnableSet(19,en);break;//gen 1 toms 1	
	case 42:channelPitchSet(16,100); channelOctaveSet(16,7); channelEnableSet(22,en);break;//gen 2 hi hat closed
	case 43:channelPitchSet(13,42); channelOctaveSet(13,4); channelEnableSet(19,en);break;//gen 1 toms 2	
	case 44:channelPitchSet(16,100); channelOctaveSet(16,7); channelEnableSet(22,en);break;//gen 2 hi hat pedal
	case 45:channelPitchSet(13,84); channelOctaveSet(13,4); channelEnableSet(19,en);break;//gen 1 toms 3	
	case 46:channelPitchSet(16,100); channelOctaveSet(16,7); channelEnableSet(22,en);break;//gen 2 hi hat open
	case 47:channelPitchSet(13,126); channelOctaveSet(13,4); channelEnableSet(19,en);break;//gen 1 toms 4	
	case 48:channelPitchSet(13,168); channelOctaveSet(13,4); channelEnableSet(19,en);break;//gen 1 toms 5	
	case 50:channelPitchSet(13,210); channelOctaveSet(13,4); channelEnableSet(19,en);break;//gen 1 toms 6		
}	
}


void SAA1099MEGA :: drumsOn( byte note, byte velocity)
{

switch(note)
{
  case 35: starttime1 = millis(); timeren1 = 1; noisePlay(note,1); break;
  case 36: starttime2 = millis(); timeren2 = 1; noisePlay(note,1); break;//start timer on note
  case 38: starttime3 = millis(); timeren3 = 1; noisePlay(note,1); break;
  case 40: starttime4 = millis(); timeren4 = 1; noisePlay(note,1); break;
  case 41: starttime5 = millis(); timeren5 = 1; noisePlay(note,1); break;
  case 42: starttime6 = millis(); timeren6 = 1; noisePlay(note,1); break;
  case 43: starttime7 = millis(); timeren7 = 1; noisePlay(note,1); break;
  case 44: starttime8 = millis(); timeren8 = 1; noisePlay(note,1); break;
  case 45: starttime9 = millis(); timeren9 = 1; noisePlay(note,1); break;
  case 46: starttime10 = millis(); timeren10 = 1; noisePlay(note,1); break;
  case 47: starttime11 = millis(); timeren11 = 1; noisePlay(note,1); break;
  case 48: starttime12 = millis(); timeren12 = 1; noisePlay(note,1); break;
  case 50: starttime13 = millis(); timeren13 = 1; noisePlay(note,1); break;
  
  
  
  
  
 
  
}
 

if(velocity == 0)
{
	

switch(note)
{
	case 35:  timeren1 = 0; noisePlay(note,0); break;
	case 36:  timeren2 = 0; noisePlay(note,0); break;
	case 38:  timeren3 = 0; noisePlay(note,0); break;
	case 40:  timeren4 = 0; noisePlay(note,0); break;
	case 41:  timeren5 = 0; noisePlay(note,0); break;
	case 42:  timeren6 = 0; noisePlay(note,0); break;
	case 43:  timeren7 = 0; noisePlay(note,0); break;
	case 44:  timeren8 = 0; noisePlay(note,0); break;
	case 45:  timeren9 = 0; noisePlay(note,0); break;
	case 46:  timeren10 = 0; noisePlay(note,0); break;
	case 47:  timeren11 = 0; noisePlay(note,0); break;
	case 48:  timeren12 = 0; noisePlay(note,0); break;
	case 50:  timeren13 = 0; noisePlay(note,0); break;	
}
		
}
}	
	
	
void SAA1099MEGA :: drumsOff( byte note)
{


switch(note)
{
	case 35:  timeren1 = 0; noisePlay(note,0); break;
	case 36:  timeren2 = 0; noisePlay(note,0); break;
	case 38:  timeren3 = 0; noisePlay(note,0); break;
	case 40:  timeren4 = 0; noisePlay(note,0); break;
	case 41:  timeren5 = 0; noisePlay(note,0); break;
	case 42:  timeren6 = 0; noisePlay(note,0); break;
	case 43:  timeren7 = 0; noisePlay(note,0); break;
	case 44:  timeren8 = 0; noisePlay(note,0); break;
	case 45:  timeren9 = 0; noisePlay(note,0); break;
	case 46:  timeren10 = 0; noisePlay(note,0); break;
	case 47:  timeren11 = 0; noisePlay(note,0); break;
	case 48:  timeren12 = 0; noisePlay(note,0); break;
	case 50:  timeren13 = 0; noisePlay(note,0); break;	
}
	
}



void SAA1099MEGA :: volume(byte ch, byte vol)
{
	
	byte level = map(vol,0,127,0,15);

	switch(ch)
	{
	case 1:	
	switch(level)
	{
		case 0:  loadRegistor(0x00,  1, B00000000); break;
        case 1:  loadRegistor(0x00,  1, B00010001); break;	
        case 2:  loadRegistor(0x00,  1, B00100010); break;	
        case 3:  loadRegistor(0x00,  1, B00110011); break;	
        case 4:  loadRegistor(0x00,  1, B01000100); break;	
        case 5:  loadRegistor(0x00,  1, B01010101); break;	
        case 6:  loadRegistor(0x00,  1, B01100110); break;	
        case 7:  loadRegistor(0x00,  1, B01110111); break;	
        case 8:  loadRegistor(0x00,  1, B10001000); break;	
        case 9:  loadRegistor(0x00,  1, B10011001); break;	
        case 10: loadRegistor(0x00,  1, B10101010); break;	
        case 11: loadRegistor(0x00,  1, B10111011); break;	
        case 12: loadRegistor(0x00,  1, B11001100); break;	
        case 13: loadRegistor(0x00,  1, B11011101); break;	
        case 14: loadRegistor(0x00,  1, B11101110); break;	
        case 15: loadRegistor(0x00,  1, B11111111); break;		
	}
	break;
	
	
		case 2:	
	switch(level)
	{
		case 0:  loadRegistor(0x1,  1, B00000000); break;
        case 1:  loadRegistor(0x1,  1, B00010001); break;	
        case 2:  loadRegistor(0x1,  1, B00100010); break;	
        case 3:  loadRegistor(0x1,  1, B00110011); break;	
        case 4:  loadRegistor(0x1,  1, B01000100); break;	
        case 5:  loadRegistor(0x1,  1, B01010101); break;	
        case 6:  loadRegistor(0x1,  1, B01100110); break;	
        case 7:  loadRegistor(0x1,  1, B01110111); break;	
        case 8:  loadRegistor(0x1,  1, B10001000); break;	
        case 9:  loadRegistor(0x1,  1, B10011001); break;	
        case 10: loadRegistor(0x1,  1, B10101010); break;	
        case 11: loadRegistor(0x1,  1, B10111011); break;	
        case 12: loadRegistor(0x1,  1, B11001100); break;	
        case 13: loadRegistor(0x1,  1, B11011101); break;	
        case 14: loadRegistor(0x1,  1, B11101110); break;	
        case 15: loadRegistor(0x1,  1, B11111111); break;		
	}
	break;
	
	
	
	
		case 3:	
	switch(level)
	{
		case 0:  loadRegistor(0x2,  1, B00000000); break;
        case 1:  loadRegistor(0x2,  1, B00010001); break;	
        case 2:  loadRegistor(0x2,  1, B00100010); break;	
        case 3:  loadRegistor(0x2,  1, B00110011); break;	
        case 4:  loadRegistor(0x2,  1, B01000100); break;	
        case 5:  loadRegistor(0x2,  1, B01010101); break;	
        case 6:  loadRegistor(0x2,  1, B01100110); break;	
        case 7:  loadRegistor(0x2,  1, B01110111); break;	
        case 8:  loadRegistor(0x2,  1, B10001000); break;	
        case 9:  loadRegistor(0x2,  1, B10011001); break;	
        case 10: loadRegistor(0x2,  1, B10101010); break;	
        case 11: loadRegistor(0x2,  1, B10111011); break;	
        case 12: loadRegistor(0x2,  1, B11001100); break;	
        case 13: loadRegistor(0x2,  1, B11011101); break;	
        case 14: loadRegistor(0x2,  1, B11101110); break;	
        case 15: loadRegistor(0x2,  1, B11111111); break;		
	}
	break;
	
	
	
	
		case 4:	
	switch(level)
	{
		case 0:  loadRegistor(0x3,  1, B00000000); break;
        case 1:  loadRegistor(0x3,  1, B00010001); break;	
        case 2:  loadRegistor(0x3,  1, B00100010); break;	
        case 3:  loadRegistor(0x3,  1, B00110011); break;	
        case 4:  loadRegistor(0x3,  1, B01000100); break;	
        case 5:  loadRegistor(0x3,  1, B01010101); break;	
        case 6:  loadRegistor(0x3,  1, B01100110); break;	
        case 7:  loadRegistor(0x3,  1, B01110111); break;	
        case 8:  loadRegistor(0x3,  1, B10001000); break;	
        case 9:  loadRegistor(0x3,  1, B10011001); break;	
        case 10: loadRegistor(0x3,  1, B10101010); break;	
        case 11: loadRegistor(0x3,  1, B10111011); break;	
        case 12: loadRegistor(0x3,  1, B11001100); break;	
        case 13: loadRegistor(0x3,  1, B11011101); break;	
        case 14: loadRegistor(0x3,  1, B11101110); break;	
        case 15: loadRegistor(0x3,  1, B11111111); break;		
	}
	break;
	
	
	
		case 5:	
	switch(level)
	{
		case 0:  loadRegistor(0x4,  1, B00000000); break;
        case 1:  loadRegistor(0x4,  1, B00010001); break;	
        case 2:  loadRegistor(0x4,  1, B00100010); break;	
        case 3:  loadRegistor(0x4,  1, B00110011); break;	
        case 4:  loadRegistor(0x4,  1, B01000100); break;	
        case 5:  loadRegistor(0x4,  1, B01010101); break;	
        case 6:  loadRegistor(0x4,  1, B01100110); break;	
        case 7:  loadRegistor(0x4,  1, B01110111); break;	
        case 8:  loadRegistor(0x4,  1, B10001000); break;	
        case 9:  loadRegistor(0x4,  1, B10011001); break;	
        case 10: loadRegistor(0x4,  1, B10101010); break;	
        case 11: loadRegistor(0x4,  1, B10111011); break;	
        case 12: loadRegistor(0x4,  1, B11001100); break;	
        case 13: loadRegistor(0x4,  1, B11011101); break;	
        case 14: loadRegistor(0x4,  1, B11101110); break;	
        case 15: loadRegistor(0x4,  1, B11111111); break;		
	}
	break;
	
	
	
		case 6:	
	switch(level)
	{
		case 0:  loadRegistor(0x5,  1, B00000000); break;
        case 1:  loadRegistor(0x5,  1, B00010001); break;	
        case 2:  loadRegistor(0x5,  1, B00100010); break;	
        case 3:  loadRegistor(0x5,  1, B00110011); break;	
        case 4:  loadRegistor(0x5,  1, B01000100); break;	
        case 5:  loadRegistor(0x5,  1, B01010101); break;	
        case 6:  loadRegistor(0x5,  1, B01100110); break;	
        case 7:  loadRegistor(0x5,  1, B01110111); break;	
        case 8:  loadRegistor(0x5,  1, B10001000); break;	
        case 9:  loadRegistor(0x5,  1, B10011001); break;	
        case 10: loadRegistor(0x5,  1, B10101010); break;	
        case 11: loadRegistor(0x5,  1, B10111011); break;	
        case 12: loadRegistor(0x5,  1, B11001100); break;	
        case 13: loadRegistor(0x5,  1, B11011101); break;	
        case 14: loadRegistor(0x5,  1, B11101110); break;	
        case 15: loadRegistor(0x5,  1, B11111111); break;		
	}
	break;
	
	
	/////////////////////////////////////////////////////////////////////////////
	
		case 7:	
	switch(level)
	{
		case 0:  loadRegistor(0x00,  2, B00000000); break;
        case 1:  loadRegistor(0x00,  2, B00010001); break;	
        case 2:  loadRegistor(0x00,  2, B00100010); break;	
        case 3:  loadRegistor(0x00,  2, B00110011); break;	
        case 4:  loadRegistor(0x00,  2, B01000100); break;	
        case 5:  loadRegistor(0x00,  2, B01010101); break;	
        case 6:  loadRegistor(0x00,  2, B01100110); break;	
        case 7:  loadRegistor(0x00,  2, B01110111); break;	
        case 8:  loadRegistor(0x00,  2, B10001000); break;	
        case 9:  loadRegistor(0x00,  2, B10011001); break;	
        case 10: loadRegistor(0x00,  2, B10101010); break;	
        case 11: loadRegistor(0x00,  2, B10111011); break;	
        case 12: loadRegistor(0x00,  2, B11001100); break;	
        case 13: loadRegistor(0x00,  2, B11011101); break;	
        case 14: loadRegistor(0x00,  2, B11101110); break;	
        case 15: loadRegistor(0x00,  2, B11111111); break;		
	}
	break;
	
	
		case 8:	
	switch(level)
	{
		case 0:  loadRegistor(0x1,  2, B00000000); break;
        case 1:  loadRegistor(0x1,  2, B00010001); break;	
        case 2:  loadRegistor(0x1,  2, B00100010); break;	
        case 3:  loadRegistor(0x1,  2, B00110011); break;	
        case 4:  loadRegistor(0x1,  2, B01000100); break;	
        case 5:  loadRegistor(0x1,  2, B01010101); break;	
        case 6:  loadRegistor(0x1,  2, B01100110); break;	
        case 7:  loadRegistor(0x1,  2, B01110111); break;	
        case 8:  loadRegistor(0x1,  2, B10001000); break;	
        case 9:  loadRegistor(0x1,  2, B10011001); break;	
        case 10: loadRegistor(0x1,  2, B10101010); break;	
        case 11: loadRegistor(0x1,  2, B10111011); break;	
        case 12: loadRegistor(0x1,  2, B11001100); break;	
        case 13: loadRegistor(0x1,  2, B11011101); break;	
        case 14: loadRegistor(0x1,  2, B11101110); break;	
        case 15: loadRegistor(0x1,  2, B11111111); break;		
	}
	break;
	
	
	
	
		case 9:	
	switch(level)
	{
		case 0:  loadRegistor(0x2,  2, B00000000); break;
        case 1:  loadRegistor(0x2,  2, B00010001); break;	
        case 2:  loadRegistor(0x2,  2, B00100010); break;	
        case 3:  loadRegistor(0x2,  2, B00110011); break;	
        case 4:  loadRegistor(0x2,  2, B01000100); break;	
        case 5:  loadRegistor(0x2,  2, B01010101); break;	
        case 6:  loadRegistor(0x2,  2, B01100110); break;	
        case 7:  loadRegistor(0x2,  2, B01110111); break;	
        case 8:  loadRegistor(0x2,  2, B10001000); break;	
        case 9:  loadRegistor(0x2,  2, B10011001); break;	
        case 10: loadRegistor(0x2,  2, B10101010); break;	
        case 11: loadRegistor(0x2,  2, B10111011); break;	
        case 12: loadRegistor(0x2,  2, B11001100); break;	
        case 13: loadRegistor(0x2,  2, B11011101); break;	
        case 14: loadRegistor(0x2,  2, B11101110); break;	
        case 15: loadRegistor(0x2,  2, B11111111); break;		
	}
	break;
	
	
	
	
		case 10:	
	switch(level)
	{
		case 0:  loadRegistor(0x3,  2, B00000000); break;
        case 1:  loadRegistor(0x3,  2, B00010001); break;	
        case 2:  loadRegistor(0x3,  2, B00100010); break;	
        case 3:  loadRegistor(0x3,  2, B00110011); break;	
        case 4:  loadRegistor(0x3,  2, B01000100); break;	
        case 5:  loadRegistor(0x3,  2, B01010101); break;	
        case 6:  loadRegistor(0x3,  2, B01100110); break;	
        case 7:  loadRegistor(0x3,  2, B01110111); break;	
        case 8:  loadRegistor(0x3,  2, B10001000); break;	
        case 9:  loadRegistor(0x3,  2, B10011001); break;	
        case 10: loadRegistor(0x3,  2, B10101010); break;	
        case 11: loadRegistor(0x3,  2, B10111011); break;	
        case 12: loadRegistor(0x3,  2, B11001100); break;	
        case 13: loadRegistor(0x3,  2, B11011101); break;	
        case 14: loadRegistor(0x3,  2, B11101110); break;	
        case 15: loadRegistor(0x3,  2, B11111111); break;		
	}
	break;
	
	
	
		case 11:	
	switch(level)
	{
		case 0:  loadRegistor(0x4,  2, B00000000); break;
        case 1:  loadRegistor(0x4,  2, B00010001); break;	
        case 2:  loadRegistor(0x4,  2, B00100010); break;	
        case 3:  loadRegistor(0x4,  2, B00110011); break;	
        case 4:  loadRegistor(0x4,  2, B01000100); break;	
        case 5:  loadRegistor(0x4,  2, B01010101); break;	
        case 6:  loadRegistor(0x4,  2, B01100110); break;	
        case 7:  loadRegistor(0x4,  2, B01110111); break;	
        case 8:  loadRegistor(0x4,  2, B10001000); break;	
        case 9:  loadRegistor(0x4,  2, B10011001); break;	
        case 10: loadRegistor(0x4,  2, B10101010); break;	
        case 11: loadRegistor(0x4,  2, B10111011); break;	
        case 12: loadRegistor(0x4,  2, B11001100); break;	
        case 13: loadRegistor(0x4,  2, B11011101); break;	
        case 14: loadRegistor(0x4,  2, B11101110); break;	
        case 15: loadRegistor(0x4,  2, B11111111); break;		
	}
	break;
	
	
	
		case 12:	
	switch(level)
	{
		case 0:  loadRegistor(0x5,  2, B00000000); break;
        case 1:  loadRegistor(0x5,  2, B00010001); break;	
        case 2:  loadRegistor(0x5,  2, B00100010); break;	
        case 3:  loadRegistor(0x5,  2, B00110011); break;	
        case 4:  loadRegistor(0x5,  2, B01000100); break;	
        case 5:  loadRegistor(0x5,  2, B01010101); break;	
        case 6:  loadRegistor(0x5,  2, B01100110); break;	
        case 7:  loadRegistor(0x5,  2, B01110111); break;	
        case 8:  loadRegistor(0x5,  2, B10001000); break;	
        case 9:  loadRegistor(0x5,  2, B10011001); break;	
        case 10: loadRegistor(0x5,  2, B10101010); break;	
        case 11: loadRegistor(0x5,  2, B10111011); break;	
        case 12: loadRegistor(0x5,  2, B11001100); break;	
        case 13: loadRegistor(0x5,  2, B11011101); break;	
        case 14: loadRegistor(0x5,  2, B11101110); break;	
        case 15: loadRegistor(0x5,  2, B11111111); break;		
	}
	break;
	
	
	
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	
	
	
	
	
		case 13:	
	switch(level)
	{
		case 0:  loadRegistor(0x00,  3, B00000000); break;
        case 1:  loadRegistor(0x00,  3, B00010001); break;	
        case 2:  loadRegistor(0x00,  3, B00100010); break;	
        case 3:  loadRegistor(0x00,  3, B00110011); break;	
        case 4:  loadRegistor(0x00,  3, B01000100); break;	
        case 5:  loadRegistor(0x00,  3, B01010101); break;	
        case 6:  loadRegistor(0x00,  3, B01100110); break;	
        case 7:  loadRegistor(0x00,  3, B01110111); break;	
        case 8:  loadRegistor(0x00,  3, B10001000); break;	
        case 9:  loadRegistor(0x00,  3, B10011001); break;	
        case 10: loadRegistor(0x00,  3, B10101010); break;	
        case 11: loadRegistor(0x00,  3, B10111011); break;	
        case 12: loadRegistor(0x00,  3, B11001100); break;	
        case 13: loadRegistor(0x00,  3, B11011101); break;	
        case 14: loadRegistor(0x00,  3, B11101110); break;	
        case 15: loadRegistor(0x00,  3, B11111111); break;		
	}
	break;
	
	
		case 14:	
	switch(level)
	{
		case 0:  loadRegistor(0x1,  3, B00000000); break;
        case 1:  loadRegistor(0x1,  3, B00010001); break;	
        case 2:  loadRegistor(0x1,  3, B00100010); break;	
        case 3:  loadRegistor(0x1,  3, B00110011); break;	
        case 4:  loadRegistor(0x1,  3, B01000100); break;	
        case 5:  loadRegistor(0x1,  3, B01010101); break;	
        case 6:  loadRegistor(0x1,  3, B01100110); break;	
        case 7:  loadRegistor(0x1,  3, B01110111); break;	
        case 8:  loadRegistor(0x1,  3, B10001000); break;	
        case 9:  loadRegistor(0x1,  3, B10011001); break;	
        case 10: loadRegistor(0x1,  3, B10101010); break;	
        case 11: loadRegistor(0x1,  3, B10111011); break;	
        case 12: loadRegistor(0x1,  3, B11001100); break;	
        case 13: loadRegistor(0x1,  3, B11011101); break;	
        case 14: loadRegistor(0x1,  3, B11101110); break;	
        case 15: loadRegistor(0x1,  3, B11111111); break;		
	}
	break;
	
	
	
	
		case 15:	
	switch(level)
	{
		case 0:  loadRegistor(0x2,  3, B00000000); break;
        case 1:  loadRegistor(0x2,  3, B00010001); break;	
        case 2:  loadRegistor(0x2,  3, B00100010); break;	
        case 3:  loadRegistor(0x2,  3, B00110011); break;	
        case 4:  loadRegistor(0x2,  3, B01000100); break;	
        case 5:  loadRegistor(0x2,  3, B01010101); break;	
        case 6:  loadRegistor(0x2,  3, B01100110); break;	
        case 7:  loadRegistor(0x2,  3, B01110111); break;	
        case 8:  loadRegistor(0x2,  3, B10001000); break;	
        case 9:  loadRegistor(0x2,  3, B10011001); break;	
        case 10: loadRegistor(0x2,  3, B10101010); break;	
        case 11: loadRegistor(0x2,  3, B10111011); break;	
        case 12: loadRegistor(0x2,  3, B11001100); break;	
        case 13: loadRegistor(0x2,  3, B11011101); break;	
        case 14: loadRegistor(0x2,  3, B11101110); break;	
        case 15: loadRegistor(0x2,  3, B11111111); break;		
	}
	break;
	
	
	
	
		case 16:	
	switch(level)
	{
		case 0:  loadRegistor(0x3,  3, B00000000); break;
        case 1:  loadRegistor(0x3,  3, B00010001); break;	
        case 2:  loadRegistor(0x3,  3, B00100010); break;	
        case 3:  loadRegistor(0x3,  3, B00110011); break;	
        case 4:  loadRegistor(0x3,  3, B01000100); break;	
        case 5:  loadRegistor(0x3,  3, B01010101); break;	
        case 6:  loadRegistor(0x3,  3, B01100110); break;	
        case 7:  loadRegistor(0x3,  3, B01110111); break;	
        case 8:  loadRegistor(0x3,  3, B10001000); break;	
        case 9:  loadRegistor(0x3,  3, B10011001); break;	
        case 10: loadRegistor(0x3,  3, B10101010); break;	
        case 11: loadRegistor(0x3,  3, B10111011); break;	
        case 12: loadRegistor(0x3,  3, B11001100); break;	
        case 13: loadRegistor(0x3,  3, B11011101); break;	
        case 14: loadRegistor(0x3,  3, B11101110); break;	
        case 15: loadRegistor(0x3,  3, B11111111); break;		
	}
	break;
	
	
	
		case 17:	
	switch(level)
	{
		case 0:  loadRegistor(0x4,  3, B00000000); break;
        case 1:  loadRegistor(0x4,  3, B00010001); break;	
        case 2:  loadRegistor(0x4,  3, B00100010); break;	
        case 3:  loadRegistor(0x4,  3, B00110011); break;	
        case 4:  loadRegistor(0x4,  3, B01000100); break;	
        case 5:  loadRegistor(0x4,  3, B01010101); break;	
        case 6:  loadRegistor(0x4,  3, B01100110); break;	
        case 7:  loadRegistor(0x4,  3, B01110111); break;	
        case 8:  loadRegistor(0x4,  3, B10001000); break;	
        case 9:  loadRegistor(0x4,  3, B10011001); break;	
        case 10: loadRegistor(0x4,  3, B10101010); break;	
        case 11: loadRegistor(0x4,  3, B10111011); break;	
        case 12: loadRegistor(0x4,  3, B11001100); break;	
        case 13: loadRegistor(0x4,  3, B11011101); break;	
        case 14: loadRegistor(0x4,  3, B11101110); break;	
        case 15: loadRegistor(0x4,  3, B11111111); break;		
	}
	break;
	
	
	
		case 18:	
	switch(level)
	{
		case 0:  loadRegistor(0x5,  3, B00000000); break;
        case 1:  loadRegistor(0x5,  3, B00010001); break;	
        case 2:  loadRegistor(0x5,  3, B00100010); break;	
        case 3:  loadRegistor(0x5,  3, B00110011); break;	
        case 4:  loadRegistor(0x5,  3, B01000100); break;	
        case 5:  loadRegistor(0x5,  3, B01010101); break;	
        case 6:  loadRegistor(0x5,  3, B01100110); break;	
        case 7:  loadRegistor(0x5,  3, B01110111); break;	
        case 8:  loadRegistor(0x5,  3, B10001000); break;	
        case 9:  loadRegistor(0x5,  3, B10011001); break;	
        case 10: loadRegistor(0x5,  3, B10101010); break;	
        case 11: loadRegistor(0x5,  3, B10111011); break;	
        case 12: loadRegistor(0x5,  3, B11001100); break;	
        case 13: loadRegistor(0x5,  3, B11011101); break;	
        case 14: loadRegistor(0x5,  3, B11101110); break;	
        case 15: loadRegistor(0x5,  3, B11111111); break;		
	}
	break;

	
	
	}
}











