#include "Arduino.h"


class   SAA1099MEGA
{

     

    public:
	
	SAA1099MEGA();
    void WRpulse();
    void A0low();
    void A0high();
    void CS1low();
    void CS1high();
    void CS2low();
    void CS2high();
    void CS3low();
    void CS3high();
    void loadAddressByteToChip(byte address, byte chip);
    void loadDataByteToChip(byte data, byte chip);
    void loadRegistor(byte address, byte chip, byte data);
    void defaultRegistorSet(byte chip);
    void channelEnableSet(byte ch, bool en);
    void channelPitchSet(byte ch, byte pitch);
    void loadOctaveByteToChip(byte ch, byte range);
    void channelOctaveSet(byte ch, byte range);
    void powerUpRegistorSet();
	void tuneEeprom();
	void defaultTuneEeprom();
	void printNotes();
	void notePlay(byte channel, byte midinote, bool enable);
	void readMidiData();
	void midiNoteOn(byte channel, byte note,byte velocity);
	void midiNoteOff(byte channel, byte note);
    void drumsOn(byte note, byte velocity);
    void drumsOff(byte note);
	void noisePlay(byte note, byte en);
    void volume(byte ch, byte vol);
	
	
    private:
    
	
	bool timeren1;
	bool timeren2;
	bool timeren3;
	bool timeren4;
	bool timeren5;
	bool timeren6;
	bool timeren7;
	bool timeren8;
	bool timeren9;
	bool timeren10;
	bool timeren11;
	bool timeren12;
	bool timeren13;
	
	
	
	unsigned long starttime1; 
	unsigned long starttime2; 
	unsigned long starttime3; 
	unsigned long starttime4; 
	unsigned long starttime5; 
	unsigned long starttime6; 
	unsigned long starttime7; 
	unsigned long starttime8; 
	unsigned long starttime9; 
	unsigned long starttime10; 
	unsigned long starttime11; 
	unsigned long starttime12; 
	unsigned long starttime13; 
	
	
	
	
	
	byte midiEn;
	byte tunepos;
	byte b;
	byte c;
	byte cs;
	byte d;
	byte ds;
	byte e;
	byte f;
	byte fs;
	byte g;
	byte gs;
	byte a;
	byte as;
	

bool chOn1;
bool chOn2;
bool chOn3;
bool chOn4;
bool chOn5;
bool chOn6;
bool chOn7;
bool chOn8;
bool chOn9;
bool chOn10;
bool chOn11;
bool chOn12;
bool chOn13;
bool chOn14;
bool chOn15;
bool chOn16;

byte chOnPitch1;
byte chOnPitch2;
byte chOnPitch3;
byte chOnPitch4;
byte chOnPitch5;
byte chOnPitch6;
byte chOnPitch7;
byte chOnPitch8;
byte chOnPitch9;
byte chOnPitch10;
byte chOnPitch11;
byte chOnPitch12;
byte chOnPitch13;
byte chOnPitch14;
byte chOnPitch15;
byte chOnPitch16;


};////////////////////////////////////////////////////////